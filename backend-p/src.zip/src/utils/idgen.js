import crypto from "crypto";
export function newComplaintId() {
  // 12‐byte random -> base32-like 20 chars, prefix C
  return "C" + crypto.randomBytes(12).toString("base64url").replace(/-/g,"A").replace(/_/g,"Z");
}
export function shortVerification() {
  // 12-char receipt (base36)
  return crypto.randomBytes(6).toString("base64url").slice(0,12).toUpperCase();
}
