// src/middleware/auth.middleware.js
import jwt from "jsonwebtoken";
import { env } from "../config/env.js"; // already created earlier

export function requireAuth(req, res, next) {
  try {
    const h = req.headers.authorization || "";
    if (!h.startsWith("Bearer ")) {
      return res.status(401).json({ ok: false, error: "no_token" });
    }
    const token = h.slice(7);
    const payload = jwt.verify(token, env.JWT_ACCESS_SECRET); // throws if invalid/expired

    // attach to request for downstream handlers
    req.user = {
      user_id: payload.sub,
      vit_id: payload.vit_id,
      roles: payload.roles || [],
      perms: payload.perms || [],
    };
    next();
  } catch (e) {
    return res.status(401).json({ ok: false, error: "invalid_token" });
  }
}
