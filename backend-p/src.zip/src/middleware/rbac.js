// src/services/rbac.service.js
// Map role_ids to permissions (fill later)
export function getPermissions(roleIds = []) {
  // simple example: role 1 = student, 2 = faculty, 3 = warden, 4 = security, 99 = admin
  const set = new Set();
  for (const r of roleIds) {
    switch (String(r)) {
      case "1": set.add("student:read"); break;
      case "2": set.add("faculty:read"); break;
      case "3": set.add("warden:read"); break;
      case "4": set.add("security:read"); break;
      case "99": set.add("admin:all"); break;
      default: break;
    }
  }
  return Array.from(set);
}
