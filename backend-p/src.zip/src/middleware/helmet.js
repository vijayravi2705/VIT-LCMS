// src/middleware/helmet.js
export const corsOptions = { origin: ["http://localhost:3000"], credentials: true };

// src/middleware/rateLimit.js
import rateLimit from "express-rate-limit";
export const baseLimiter = rateLimit({ windowMs: 60_000, max: 100 });
export const loginLimiter = rateLimit({ windowMs: 5*60_000, max: 5 });

// src/middleware/audit.js
import crypto from "crypto";
export function audit(req,_res,next){ req.cid=crypto.randomUUID(); next(); }

// src/middleware/error.js
export default function errorHandler(err,_req,res,_next){
  console.error("[error]", err); res.status(err.status||500).json({ok:false,error:err.message||"Server error"});
}
