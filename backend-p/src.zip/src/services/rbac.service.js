const rolePerms = {
  student: ["complaint:create:self", "complaint:read:self"],
  faculty: ["complaint:create","complaint:read:block","complaint:update:block","complaint:escalate"],
  warden:  ["complaint:read:block","complaint:update:block","complaint:resolve"],
  security:["complaint:create","complaint:read:gate"],
  admin:   ["admin:*","complaint:read:all"]
};
export function getPermissions(roles=[]) {
  const s = new Set(); roles.forEach(r => (rolePerms[r]||[]).forEach(p=>s.add(p))); return [...s];
}
