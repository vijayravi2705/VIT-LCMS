// src/services/hash.service.js
import bcrypt from "bcryptjs";

// plain -> hash (not used right now, but keep it)
export async function hashPassword(plain) {
  return bcrypt.hash(plain, 10);
}

// verify stored hash against submitted plain
export async function verifyPassword(storedHash, submittedPlain) {
  if (!storedHash || !submittedPlain) return false;
  return bcrypt.compare(submittedPlain, storedHash);
}
