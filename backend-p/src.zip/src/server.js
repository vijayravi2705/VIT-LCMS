import { baseLimiter } from "./middleware/rateLimit.js";
import meRoutes from "./routes/me.routes.js";

import express from "express";
import cors from "cors";
import morgan from "morgan";
import authRoutes from "./routes/auth.routes.js";
import { corsOptions } from "./middleware/helmet.js";

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(cors(corsOptions));
app.use(morgan("dev"));

// health
app.get("/api/health", (req, res) => res.json({ ok: true }));

// auth
app.use("/api/auth", authRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API listening on http://localhost:${PORT}`));

app.use("/api", baseLimiter);

// src/server.js
app.use("/api", meRoutes);
console.log("Routes mounted: /api/auth, /api/student");
