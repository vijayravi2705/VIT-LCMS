// src/dal/student.dal.js
import { db } from "../db/mysql.js";

/** Fetch student profile by vit_id */
export async function getStudentProfileByVitId(vitId) {
  const [rows] = await db.execute(
    `SELECT vit_id, full_name, email, phone,
            hostel_type, block_code, room_type, room_no,
            degree, school, course, dob, blood_group,
            mess_type, mess_caterer
     FROM student_profile
     WHERE vit_id = ?`,
    [vitId]
  );
  return rows[0] || null;
}

/** Dashboard counts for a student (their filed complaints) */
export async function getStudentSummary(vitId) {
  // total filed by this vit_id
  const [[total]] = await db.execute(
    `SELECT COUNT(*) AS total
       FROM complaint
      WHERE created_by_vit = ?`,
    [vitId]
  );

  // latest status per complaint (uses last complaint_log row if you like; for now use complaint.status)
  const [[resolved]] = await db.execute(
    `SELECT COUNT(*) AS resolved
       FROM complaint
      WHERE created_by_vit = ?
        AND status = 'resolved'`,
    [vitId]
  );

  const [[pending]] = await db.execute(
    `SELECT COUNT(*) AS pending
       FROM complaint
      WHERE created_by_vit = ?
        AND status IN ('submitted','in_review','in_progress')`,
    [vitId]
  );

  const [[rejected]] = await db.execute(
    `SELECT COUNT(*) AS rejected
       FROM complaint
      WHERE created_by_vit = ?
        AND status = 'rejected'`,
    [vitId]
  );

  // recent 10 complaints (for list)
  const [recent] = await db.execute(
    `SELECT complaint_id, title, category, subcategory, severity, status, created_on
       FROM complaint
      WHERE created_by_vit = ?
      ORDER BY created_on DESC
      LIMIT 10`,
    [vitId]
  );

  return {
    total: total.total || 0,
    resolved: resolved.resolved || 0,
    pending: pending.pending || 0,
    rejected: rejected.rejected || 0,
    recent,
  };
}
