import { pool } from "../config/db.js";
import { recordHash } from "../utils/hashchain.js";

// CREATE complaint (transaction)
export async function createComplaintTx({ complaint, parties, firstLog }) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.query(
      `INSERT INTO complaint
       (complaint_id,title,description,severity,category,subcategory,status,filed_by,
        created_by_vit,created_on,assigned_block,verification_code)
       VALUES (:id,:t,:d,:sev,:cat,:sub,:st,:by,:vit,NOW(),:blk,:code)`,
      {
        id: complaint.complaint_id, t: complaint.title, d: complaint.description,
        sev: complaint.severity, cat: complaint.category, sub: complaint.subcategory,
        st: complaint.status, by: complaint.filed_by, vit: complaint.created_by_vit,
        blk: complaint.assigned_block, code: complaint.verification_code
      }
    );

    if (parties?.length) {
      for (const p of parties) {
        await conn.query(
          `INSERT INTO complaint_party
            (cp_id, complaint_id, vit_id, party_role, is_primary, notes)
           VALUES (:id,:cid,:vit,:role,:pri,:notes)`,
          { id: p.cp_id, cid: complaint.complaint_id, vit: p.vit_id, role: p.party_role, pri: p.is_primary?1:0, notes: p.notes||null }
        );
      }
    }

    // log chain
    const prevHash = "0".repeat(64);
    const rh = recordHash(prevHash, firstLog);
    await conn.query(
      `INSERT INTO complaint_log
        (log_id, complaint_id, actor_vit_id, action, status_after, notes, created_on, prev_hash, record_hash)
       VALUES(:id,:cid,:actor,:act,:status,:notes,NOW(),:prev,:rec)`,
      { id:firstLog.log_id, cid:complaint.complaint_id, actor:firstLog.actor_vit_id,
        act:firstLog.action, status:firstLog.status_after, notes:firstLog.notes||null,
        prev:prevHash, rec:rh }
    );

    await conn.commit();
    return true;
  } catch(e) {
    await conn.rollback(); throw e;
  } finally { conn.release(); }
}

// LIST for faculty dashboard/emergency etc.
export async function listComplaintsBasic({ limit=50, severity, status, order="desc" } = {}) {
  let sql = `SELECT complaint_id,title,severity,category,status,assigned_block,created_on
             FROM complaint WHERE 1=1`;
  const params = {};
  if (severity){ sql += " AND severity=:sev"; params.sev = severity; }
  if (status){ sql += " AND status=:st"; params.st = status; }
  sql += ` ORDER BY created_on ${order==="asc"?"ASC":"DESC"} LIMIT :lim`;
  params.lim = +limit;
  const [rows] = await pool.query(sql, params);
  return rows;
}

// one complaint (decrypt happens in route)
export async function getComplaintFull(cid){
  const [[row]] = await pool.query(`SELECT * FROM complaint WHERE complaint_id=:id`,{id:cid});
  if(!row) return null;
  const [parties] = await pool.query(`SELECT * FROM complaint_party WHERE complaint_id=:id`,{id:cid});
  const [logs]    = await pool.query(`SELECT * FROM complaint_log   WHERE complaint_id=:id ORDER BY created_on ASC`,{id:cid});
  const [files]   = await pool.query(`SELECT * FROM attachment     WHERE complaint_id=:id`,{id:cid});
  return { complaint: row, parties, logs, files };
}

// append log (keeps chain)
export async function appendLog({ log, prevHash }) {
  const rh = recordHash(prevHash, log);
  await pool.query(
    `INSERT INTO complaint_log
     (log_id,complaint_id,actor_vit_id,action,status_after,notes,created_on,prev_hash,record_hash)
     VALUES(:id,:cid,:actor,:action,:status,:notes,NOW(),:prev,:rec)`,
     { id:log.log_id, cid:log.complaint_id, actor:log.actor_vit_id, action:log.action,
       status:log.status_after, notes:log.notes||null, prev:prevHash, rec:rh }
  );
  return rh;
}

export async function lastLogHash(cid){
  const [[l]] = await pool.query(
    `SELECT record_hash FROM complaint_log WHERE complaint_id=:id ORDER BY created_on DESC LIMIT 1`,{id:cid});
  return l?.record_hash || "0".repeat(64);
}

export async function updateComplaintStatus(cid, status){
  await pool.query(`UPDATE complaint SET status=:s WHERE complaint_id=:id`,{s:status,id:cid});
}
