// src/controllers/student.controller.js
import { db } from "../db/mysql.js";

export async function getStudentProfile(req, res, next) {
  try {
    const vitId = req.user?.vit_id;
    if (!vitId) return res.status(401).json({ ok: false, error: "no_vit" });

    const [rows] = await db.query(
      `SELECT vit_id, full_name, email, phone, hostel_type, block_code, room_type, room_no,
              degree, school, course, dob, blood_group, mess_type, mess_caterer
         FROM student_profile
        WHERE vit_id = ?`,
      [vitId]
    );
    if (rows.length === 0) return res.status(404).json({ ok: false, error: "profile_not_found" });
    res.json({ ok: true, profile: rows[0] });
  } catch (e) { next(e); }
}

export async function getStudentSummary(req, res, next) {
  try {
    const vitId = req.user?.vit_id;
    if (!vitId) return res.status(401).json({ ok: false, error: "no_vit" });

    const [[counts]] = await db.query(
      `SELECT
         COUNT(*) AS total,
         SUM(status='resolved') AS resolved,
         SUM(status IN ('submitted','in_review','in_progress')) AS pending,
         SUM(status='rejected') AS rejected
       FROM complaint
       WHERE created_by_vit = ?`,
      [vitId]
    );

    const [recent] = await db.query(
      `SELECT complaint_id, title, category, subcategory, severity, status, created_on
         FROM complaint
        WHERE created_by_vit = ?
        ORDER BY created_on DESC
        LIMIT 5`,
      [vitId]
    );

    res.json({ ok: true, summary: { ...counts, recent } });
  } catch (e) { next(e); }
}
