// src/controllers/auth.controller.js
import jwt from "jsonwebtoken";
import { getUserWithRolesByUsername } from "../dal/user.dal.js";
import { verifyPassword } from "../services/hash.service.js";
import { env } from "../config/env.js";

export async function login(req, res, next) {
  try {
    const { username, password } = req.body;
    const u = await getUserWithRolesByUsername(username);

    if (!u || !u.is_active) {
      return res.status(401).json({ ok: false, error: "invalid credentials" });
    }

    const ok = await verifyPassword(u.password_hash, password);
    if (!ok) {
      return res.status(401).json({ ok: false, error: "invalid credentials" });
    }

    const roles = (u.roles || "").split(",").filter(Boolean);
    const perms = []; // keep empty for now or use getPermissions(roles)

    if (!env.JWT_ACCESS_SECRET) {
      // avoid secret missing crash
      return res.status(500).json({ ok: false, error: "jwt_secret_missing" });
    }

    const token = jwt.sign(
      { sub: u.user_id, vit_id: u.vit_id, roles, perms },
      env.JWT_ACCESS_SECRET,
      { expiresIn: env.JWT_ACCESS_TTL || "20m" }
    );

    return res.json({
      ok: true,
      token,
      me: {
        user_id: u.user_id,
        vit_id: u.vit_id,
        username: u.vtop_username,
        roles
      }
    });
  } catch (err) {
    next(err);
  }
}
