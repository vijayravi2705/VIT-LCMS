import { Router } from "express";
import { auth } from "../middleware/auth.js";
import { requirePerm } from "../middleware/rbac.js";
import { newComplaintId, shortVerification } from "../utils/idgen.js";
import { encryptJSON, decryptJSON } from "../utils/crypto.js";
import { createComplaintTx, listComplaintsBasic, getComplaintFull,
         appendLog, lastLogHash, updateComplaintStatus } from "../dal/complaint.dal.js";

const r = Router();

/** Create complaint
 * body: { title, description, severity, category, subcategory, assigned_block,
 *         parties:[{cp_id,vit_id,party_role,is_primary,notes}], filed_by }
 * response: { complaint_id, verification_code }
 */
r.post("/", auth, requirePerm("complaint:create"), async (req,res,next)=>{
  try{
    const complaint_id = newComplaintId();
    const verification_code = shortVerification();

    // Encrypt sensitive text (title+description) as a JSON bundle
    const encPayload = encryptJSON({
      title: req.body.title,
      description: req.body.description
    });

    const complaint = {
      complaint_id,
      title: encPayload,                     // store ciphertext
      description: encPayload,               // (kept same for demo)
      severity: req.body.severity,
      category: req.body.category,
      subcategory: req.body.subcategory,
      status: "submitted",
      filed_by: req.body.filed_by || "student",
      created_by_vit: req.user.vit_id,
      assigned_block: req.body.assigned_block,
      verification_code
    };

    const parties = (req.body.parties||[]).map((p,i)=>({
      cp_id: p.cp_id || (1000+i),
      vit_id: p.vit_id,
      party_role: p.party_role,
      is_primary: !!p.is_primary,
      notes: p.notes||null
    }));

    const firstLog = {
      log_id: 1,
      complaint_id,
      actor_vit_id: req.user.vit_id,
      action: "created",
      status_after: "submitted",
      notes: null
    };

    await createComplaintTx({ complaint, parties, firstLog });
    res.json({ ok:true, complaint_id, verification_code });
  }catch(e){ next(e); }
});

// list (basic)
r.get("/", auth, async (req,res,next)=>{
  try {
    const data = await listComplaintsBasic({
      limit: req.query.limit||50,
      severity: req.query.severity,
      status: req.query.status
    });
    res.json({ ok:true, items:data });
  } catch(e){ next(e); }
});

// details (with decrypt for frontend)
r.get("/:id", auth, async (req,res,next)=>{
  try{
    const out = await getComplaintFull(req.params.id);
    if(!out) return res.status(404).json({ok:false,error:"Not found"});

    // decrypt title/description bundle
    const decoded = decryptJSON(out.complaint.title);
    out.complaint.title_plain = decoded.title;
    out.complaint.description_plain = decoded.description;
    delete out.complaint.title; delete out.complaint.description;

    res.json({ ok:true, ...out });
  }catch(e){ next(e); }
});

// escalate (status to in_progress + add log)
r.post("/:id/escalate", auth, requirePerm("complaint:escalate"), async (req,res,next)=>{
  try{
    const cid = req.params.id;
    const prev = await lastLogHash(cid);
    const log = {
      log_id: Date.now()%1e9,
      complaint_id: cid,
      actor_vit_id: req.user.vit_id,
      action: "escalated",
      status_after: "in_progress",
      notes: req.body.notes || null
    };
    const rh = await appendLog({ log, prevHash: prev });
    await updateComplaintStatus(cid, "in_progress");
    res.json({ ok:true, record_hash: rh });
  }catch(e){ next(e); }
});

export default r;
