// src/routes/auth.routes.js
import { Router } from "express";
import { body, validationResult } from "express-validator";
import { login } from "../controllers/auth.controller.js";
import { loginLimiter } from "../middleware/rateLimit.js";

const router = Router();

const validateLogin = [
  body("username").isString().trim().notEmpty(),
  body("password").isString().isLength({ min: 6 }),
  (req, res, next) => {
    const result = validationResult(req);
    if (!result.isEmpty()) {
      return res.status(400).json({ ok: false, errors: result.array() });
    }
    next();
  },
];

router.post("/login", loginLimiter, validateLogin, login);

export default router;
