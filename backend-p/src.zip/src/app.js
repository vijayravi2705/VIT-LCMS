import express from "express";
import cors from "cors";
import helmet from "helmet";
import { corsOptions } from "./middleware/helmet.js";
import { baseLimiter } from "./middleware/rateLimit.js";
import { audit } from "./middleware/audit.js";
import errorHandler from "./middleware/error.js";
import studentRoutes from "./routes/student.routes.js";
import authRoutes from "./routes/auth.routes.js";
import userRoutes from "./routes/user.routes.js";
import complaintRoutes from "./routes/complaint.routes.js";
import analyticsRoutes from "./routes/analytics.routes.js";
import filesRoutes from "./routes/files.routes.js";

const app = express();
app.use(helmet());
app.use(cors(corsOptions));
app.use(express.json({ limit: "3mb" }));
app.use(baseLimiter);
app.use(audit);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.use("/api/auth", authRoutes);
app.use("/api", userRoutes);
app.use("/api/complaints", complaintRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/files", filesRoutes);
app.use("/api/student", studentRoutes);
app.use(errorHandler);
export default app;
