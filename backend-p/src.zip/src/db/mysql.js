// src/db/mysql.js
import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

// Build the pool using your .env names
const pool = mysql.createPool({
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "vijayravi",
  password: process.env.DB_PASS || "#Vijayravi2705#",
  database: process.env.DB_NAME || "vit_hostel_db",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Optional: quick self-test on startup (non-fatal if it fails)
(async () => {
  try {
    const [row] = await pool.query("SELECT 1 AS ok");
    console.log("✅ MySQL connected, test result:", row?.[0]?.ok === 1 ? "OK" : row);
  } catch (err) {
    console.error("⚠️  MySQL connection test failed:", err.message);
  }
})();

// Export both ways: named and default
export const db = pool;
export default pool;
