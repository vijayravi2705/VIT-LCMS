import React, { useEffect, useMemo, useState } from "react";
import "../assets/styles/facultyhistory.css";
import FacultyLayout from "../layouts/FacultyLayout";

/** ---------------- Shared local log helpers ---------------- */
const LOG_KEY = "fcLogs";
const readLogs = (id) => {
  try {
    const all = JSON.parse(localStorage.getItem(LOG_KEY) || "{}");
    return all[id] || [];
  } catch {
    return [];
  }
};
const seedLogsIfMissing = (id, entries) => {
  try {
    const all = JSON.parse(localStorage.getItem(LOG_KEY) || "{}");
    if (!Array.isArray(all[id]) || all[id].length === 0) {
      all[id] = entries;
      localStorage.setItem(LOG_KEY, JSON.stringify(all));
    }
  } catch {
    // no-op
  }
};

/** ---------------- Faculty-filed (on behalf of student) case + logs ---------------- */
const facultyFiledCase = {
  id: "CMP-LH-B-212-20251014-0935-01",
  title: "Harassment in corridor near LH B-212",
  cat: "Safety",
  priority: "High",
  status: "In Review",
  updated: "14 Oct, 10:20",

  // who filed the report
  reporterType: "faculty",
  facultyId: "VIT12345",
  facultyName: "Dr. Jane Doe",
  facultyDept: "EEE",
  facultyDesignation: "Assistant Professor",
  facultyContact: "+91 9XXXXXX987",

  // student on whose behalf this was filed
  reporter: "Sneha R",
  regno: "22CSE1456",
  reporterDept: "CSE",
  reporterContact: "+91 9XXXXXX312",

  // place/time & content
  hostelType: "LH",
  hostelBlock: "B",
  roomNumber: "212",
  location: "LH B-212 corridor",
  submittedAt: "14 Oct, 09:35",
  subcategory: "harassment",
  incidentDateTime: "2025-10-14 09:20",
  titleSubmitted: "Harassment in corridor near LH B-212",
  summary:
    "Student reported verbal harassment by two seniors outside corridor near B-212 during morning hours.",
  details:
    "Incident occurred around 09:20 while Sneha was heading to class. Two seniors allegedly passed threatening remarks. Nearby CCTV (LH-B-2F) may have partial coverage. Student is anxious; requested anonymity. I (faculty) escorted her to counselor after initial statement.",

  // files/tags
  attachments: [
    { name: "student-statement.pdf" },
    { name: "corridor-cctv-ref.txt" },
    { name: "counselor-intake-note.png" },
  ],
  tags: ["harassment", "safety", "female-student"],

  // people
  victims: [
    {
      name: "Sneha R",
      reg: "22CSE1456",
      contact: "+91 9XXXXXX312",
      description: "Target of verbal harassment by two seniors.",
    },
  ],
  witnesses: [
    { name: "Block B floor warden", reg: "", contact: "" },
    { name: "Priya K", reg: "22ECE0912", contact: "" },
  ],
  accused: [{ name: "Unknown (two seniors)", role: "student", id: "", contact: "" }],

  // routing
  assignedTo: "Dean Office",
  adminNotes: "",
};

const logsForFacultyFiledCase = [
  {
    ts: "2025-10-14T09:35:12.000Z",
    when: "14 Oct, 09:35",
    who: "Dr. Jane Doe",
    action: "Submitted",
    note: "Filed on behalf of student Sneha R (22CSE1456) after intake.",
    meta: { reporterType: "faculty", behalfOf: "22CSE1456" },
  },
  {
    ts: "2025-10-14T09:42:05.000Z",
    when: "14 Oct, 09:42",
    who: "Dr. Jane Doe",
    action: "Added tag",
    note: "+ harassment",
    meta: { tag: "harassment" },
  },
  {
    ts: "2025-10-14T09:45:21.000Z",
    when: "14 Oct, 09:45",
    who: "Dr. Jane Doe",
    action: "Escalated",
    note: "Status set to “In Review”. Initial routing to Dean Office.",
    meta: { to: "Dean Office" },
  },
  {
    ts: "2025-10-14T10:05:11.000Z",
    when: "14 Oct, 10:05",
    who: "Dean Office",
    action: "Edited case",
    note: "Priority: “Medium” → “High”; Assigned To: “—” → “Dean Office”",
    meta: { priorityFrom: "Medium", priorityTo: "High" },
  },
  {
    ts: "2025-10-14T10:12:44.000Z",
    when: "14 Oct, 10:12",
    who: "Security Team",
    action: "Edited case",
    note: "Added attachment: corridor-cctv-ref.txt (pull requested from LH-B-2F).",
  },
  {
    ts: "2025-10-14T10:20:03.000Z",
    when: "14 Oct, 10:20",
    who: "Counseling",
    action: "Edited case",
    note: "Added attachment: counselor-intake-note.png; victim informed of support options.",
  },
];

/** ---------------- Optional demo complaints (can remove in prod) ---------------- */
const demoComplaints = [
  // faculty-filed (existing example)
  {
    id: "CMP-MH-B-217-20251012-1905-02",
    title: "Assault reported",
    cat: "Safety",
    priority: "Emergency",
    status: "Submitted",
    updated: "12 Oct, 19:07",
    reporterType: "faculty",
    facultyId: "VIT12345",
    facultyName: "Dr. Jane Doe",
    facultyDept: "EEE",
    facultyDesignation: "Assistant Professor",
    facultyContact: "+91 9XXXXXX987",
    reporter: "Pranav S",
    regno: "22EEE2211",
    location: "MH B-217",
    submittedAt: "12 Oct, 19:05",
    subcategory: "violence",
    incidentDateTime: "2025-10-12 19:00",
    titleSubmitted: "Assault reported",
    summary: "Physical altercation between students.",
    details: "Resident tutor called. Need medical check and statements.",
    attachments: [{ name: "med-report.png" }, { name: "rt-note.txt" }],
    tags: [],
    victims: [{ name: "Pranav S", reg: "22EEE2211" }],
    witnesses: [{ name: "RT on duty", reg: "", contact: "" }],
    accused: [{ name: "Unknown", role: "student", id: "", contact: "" }],
    assignedTo: "Warden Office",
    adminNotes: "",
  },

  // faculty-filed on behalf of student (NEW)
  facultyFiledCase,

  // student-filed (won’t show in History for faculty, left here for completeness)
  {
    id: "CMP-MH-A-101-20251010-2250-01",
    title: "Ragging incident",
    cat: "Safety",
    priority: "Emergency",
    status: "In Review",
    updated: "10 Oct, 22:58",
    reporterType: "student",
    reporter: "Aarav Menon",
    regno: "22BIT0346",
    reporterDept: "EEE",
    reporterContact: "+91 98XXXXXX12",
    hostelType: "MH",
    hostelBlock: "A",
    roomNumber: "101",
    submittedAt: "10 Oct, 22:50",
    location: "MH A-101",
    subcategory: "ragging",
    incidentDateTime: "2025-10-10 22:40",
    titleSubmitted: "Ragging incident",
    summary: "Verbal abuse reported near hostel A-101.",
    details: "Student alleged verbal abuse by seniors.",
    attachments: [{ name: "corridor-cam.mp4" }],
    tags: ["ragging", "safety"],
    victims: [{ name: "Aarav Menon", reg: "22BIT0346" }],
    witnesses: [{ name: "Block A guard" }],
    accused: [{ name: "Unknown", role: "student" }],
    assignedTo: "Dean Office",
    adminNotes: "",
  },
];

/**
 * FacultyHistory
 * Props:
 *  - allComplaints: array of complaint objects
 *  - profile: { facultyId: string, facultyName: string }
 *
 * Only shows complaints where reporterType==='faculty' and facultyId matches.
 * Read-only modal with tabs; Case Log tab reads from localStorage.fcLogs.
 */
export default function FacultyHistory({
  allComplaints = demoComplaints,
  profile = { facultyId: "VIT12345", facultyName: "Dr. Jane Doe" },
}) {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("All");
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [logs, setLogs] = useState([]);
  const [tab, setTab] = useState("overview"); // overview | incident | people | files | log

  // Seed logs for the “faculty filed on behalf” case if missing.
  useEffect(() => {
    seedLogsIfMissing(facultyFiledCase.id, logsForFacultyFiledCase);
  }, []);

  // Only “my submissions” (by this faculty profile)
  const mine = useMemo(() => {
    return (allComplaints || []).filter(
      (c) => c.reporterType === "faculty" && c.facultyId === profile.facultyId
    );
  }, [allComplaints, profile.facultyId]);

  // Status filter + search
  const filtered = useMemo(() => {
    let list = [...mine];

    if (filter !== "All") {
      list = list.filter((h) => h.status === filter);
    }

    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter(
        (x) =>
          x.id.toLowerCase().includes(t) ||
          x.title.toLowerCase().includes(t) ||
          (x.location || "").toLowerCase().includes(t) ||
          (x.assignedTo || "").toLowerCase().includes(t) ||
          (x.regno || "").toLowerCase().includes(t) ||
          (x.reporter || "").toLowerCase().includes(t)
      );
    }
    return list;
  }, [mine, filter, q]);

  const openPanel = (it) => {
    setSelected(it);
    setLogs(readLogs(it.id));
    setTab("overview");
    setOpen(true);
  };

  // keyboard close
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <FacultyLayout>
      <div className="fh-page">
        <header className="fh-header">
          <div>
            <h1 className="fh-title">My Submissions</h1>
            <p className="fh-sub">
              Complaints you filed as <b>{profile.facultyName}</b>.
            </p>
          </div>
          <div className="fh-actions">
            <input
              className="fh-search"
              placeholder="Search by ID, title, location, assignee…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <select
              className="fh-select"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option>All</option>
              <option>Submitted</option>
              <option>Pending</option>
              <option>In Review</option>
              <option>In Progress</option>
              <option>Resolved</option>
              <option>Rejected</option>
            </select>
          </div>
        </header>

        <div className="fh-grid">
          {filtered.map((item) => (
            <article
              key={item.id}
              className={`fh-card pr-${String(item.priority || "")
                .toLowerCase()
                .replace(" ", "-")}`}
              onClick={() => openPanel(item)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && openPanel(item)}
            >
              <div className="fh-rail" />
              <div className="fh-main">
                <h3 className="fh-card-title">{item.title}</h3>
                <div className="fh-id">{item.id}</div>
                <div className="fh-meta">
                  <span>{item.location || "—"}</span>
                  <span>•</span>
                  <span>Updated: {item.updated || "—"}</span>
                </div>
              </div>
              <div className="fh-tags" onClick={(e) => e.stopPropagation()}>
                <span className="fh-chip">{item.cat || "—"}</span>
                <span
                  className={`fh-chip tone-${(item.priority || "low").toLowerCase()}`}
                >
                  {item.priority}
                </span>
                <span className="fh-chip tone-status">{item.status}</span>

                {/* Quick badge when filed on behalf of a student */}
                {item.reporterType === "faculty" && item.regno && (
                  <span className="fh-chip tone-status">
                    Filed for {item.regno}
                  </span>
                )}
              </div>
            </article>
          ))}

          {!filtered.length && <div className="fh-empty">No submissions found.</div>}
        </div>
      </div>

      {/* -------- Modal with tabs (read-only) -------- */}
      {open && selected && (
        <div className="fh-modal show" onClick={() => setOpen(false)}>
          <div className="fh-panel" onClick={(e) => e.stopPropagation()}>
            <div className="fh-head">
              <div className="fh-titleblock">
                <h2>{selected.title}</h2>
                <div className="fh-subid">{selected.id}</div>
              </div>
              <button
                type="button"
                className="fh-xbtn"
                aria-label="Close"
                onClick={() => setOpen(false)}
              >
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <path
                    d="M6 6l12 12M18 6L6 18"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"/>
                </svg>
              </button>
            </div>

            <div className="fh-tabs">
              {["overview", "incident", "people", "files", "log"].map((t) => (
                <button
                  key={t}
                  className={`fh-tab ${tab === t ? "active" : ""}`}
                  onClick={() => setTab(t)}
                  type="button"
                >
                  {t === "overview" && "Overview"}
                  {t === "incident" && "Incident"}
                  {t === "people" && "People"}
                  {t === "files" && "Tags & Attachments"}
                  {t === "log" && `Case Log (${logs.length})`}
                  {tab === t && <i className="fh-underline" />}
                </button>
              ))}
            </div>

            <div className="fh-body">
              {tab === "overview" && (
                <section className="fh-sec">
                  <div className="fh-grid2">
                    <div>
                      <label>Status</label>
                      <div className="fh-ro">{selected.status || "—"}</div>
                    </div>
                    <div>
                      <label>Priority</label>
                      <div className="fh-ro">{selected.priority || "—"}</div>
                    </div>
                    <div>
                      <label>Category</label>
                      <div className="fh-ro">{selected.cat || "—"}</div>
                    </div>
                    <div>
                      <label>Assigned To</label>
                      <div className="fh-ro">{selected.assignedTo || "—"}</div>
                    </div>
                    <div className="span-2">
                      <label>Location</label>
                      <div className="fh-ro">{selected.location || "—"}</div>
                    </div>
                    <div className="span-2">
                      <label>Updated</label>
                      <div className="fh-ro">{selected.updated || "—"}</div>
                    </div>
                  </div>

                  <label className="fh-lab">
                    Summary
                    <div className="fh-roarea">{selected.summary || "—"}</div>
                  </label>
                  <label className="fh-lab">
                    Detailed Description
                    <div className="fh-roarea">{selected.details || "—"}</div>
                  </label>

                  {/* "Filed on behalf" callout */}
                  {selected.reporterType === "faculty" && selected.reporter && (
                    <div className="fh-note" style={{ marginTop: 10 }}>
                      Filed on behalf of: <b>{selected.reporter}</b>{" "}
                      ({selected.regno || "—"}), {selected.reporterDept || "—"} •{" "}
                      {selected.reporterContact || "—"}
                    </div>
                  )}
                </section>
              )}

              {tab === "incident" && (
                <section className="fh-sec">
                  <div className="fh-grid2">
                    <div>
                      <label>Subcategory</label>
                      <div className="fh-ro">{selected.subcategory || "—"}</div>
                    </div>
                    <div>
                      <label>Date & Time</label>
                      <div className="fh-ro">{selected.incidentDateTime || "—"}</div>
                    </div>
                    <div className="span-2">
                      <label>Title / Subject</label>
                      <div className="fh-ro">
                        {selected.titleSubmitted || selected.title || "—"}
                      </div>
                    </div>
                    <div className="span-2">
                      <label>Submitted At</label>
                      <div className="fh-ro">{selected.submittedAt || "—"}</div>
                    </div>
                  </div>
                  <div className="fh-note">
                    Filed by <b>{selected.facultyName || "—"}</b> (
                    {selected.facultyId || "—"}) • {selected.facultyDept || "—"} •{" "}
                    {selected.facultyDesignation || "—"} •{" "}
                    {selected.facultyContact || "—"}
                  </div>
                </section>
              )}

              {tab === "people" && (
                <section className="fh-sec">
                  <h4 className="fh-sec-title">Victims</h4>
                  {selected.victims?.length ? (
                    <ul className="fh-people">
                      {selected.victims.map((v, i) => (
                        <li key={`v-${i}`} className="fh-person">
                          <div className="fh-person-line">
                            <b>{v.name || "—"}</b>
                            {v.reg ? <span className="fh-tag">{v.reg}</span> : null}
                            {v.contact ? (
                              <span className="fh-tag">{v.contact}</span>
                            ) : null}
                          </div>
                          {v.description ? (
                            <div className="fh-person-note">{v.description}</div>
                          ) : null}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="fh-muted">No victims recorded.</div>
                  )}

                  <h4 className="fh-sec-title" style={{ marginTop: 14 }}>
                    Accused (if identified)
                  </h4>
                  {selected.accused?.length ? (
                    <ul className="fh-people">
                      {selected.accused.map((a, i) => (
                        <li key={`a-${i}`} className="fh-person">
                          <div className="fh-person-line">
                            <b>{a.name || "—"}</b>
                            {a.role ? (
                              <span className="fh-tag">
                                {String(a.role).toUpperCase()}
                              </span>
                            ) : null}
                            {a.id ? <span className="fh-tag">{a.id}</span> : null}
                            {a.contact ? (
                              <span className="fh-tag">{a.contact}</span>
                            ) : null}
                          </div>
                          {a.description ? (
                            <div className="fh-person-note">{a.description}</div>
                          ) : null}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="fh-muted">No accused identified in report.</div>
                  )}

                  <h4 className="fh-sec-title" style={{ marginTop: 14 }}>
                    Witnesses
                  </h4>
                  {selected.witnesses?.length ? (
                    <ul className="fh-people">
                      {selected.witnesses.map((w, i) => (
                        <li key={`w-${i}`} className="fh-person">
                          <div className="fh-person-line">
                            <b>{w.name || "—"}</b>
                            {(w.regNo || w.reg) ? (
                              <span className="fh-tag">{w.regNo || w.reg}</span>
                            ) : null}
                            {w.contact ? (
                              <span className="fh-tag">{w.contact}</span>
                            ) : null}
                          </div>
                          {w.description ? (
                            <div className="fh-person-note">{w.description}</div>
                          ) : null}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="fh-muted">No witnesses recorded.</div>
                  )}
                </section>
              )}

              {tab === "files" && (
                <section className="fh-sec">
                  <h4 className="fh-sec-title">Tags</h4>
                  <div className="fh-chips">
                    {(selected.tags || []).length ? (
                      (selected.tags || []).map((t) => (
                        <span key={t} className="fh-chip-pill">
                          {t}
                        </span>
                      ))
                    ) : (
                      <span className="fh-muted">No tags</span>
                    )}
                  </div>

                  <h4 className="fh-sec-title" style={{ marginTop: 14 }}>
                    Attachments
                  </h4>
                  {Array.isArray(selected.attachments) &&
                  selected.attachments.length ? (
                    <div className="fh-files">
                      {selected.attachments.map((f, i) => (
                        <span key={i} className="fh-file">
                          {typeof f === "string" ? f : f.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="fh-chip tone-status">No attachments</span>
                  )}
                </section>
              )}

              {tab === "log" && (
                <section className="fh-sec">
                  {!logs.length && <div className="fh-muted">No activity yet.</div>}
                  <ul className="fh-timeline">
                    {logs.map((lg, i) => (
                      <li
                        key={i}
                        className={`fh-tl-item ${lg.action?.replace(/\s+/g, "-") || ""}`}
                      >
                        <div className="fh-tl-dot" />
                        <div className="fh-tl-card">
                          <div className="fh-tl-top">
                            <span className="fh-tl-action">{lg.action}</span>
                            <span className="fh-tl-time">{lg.when}</span>
                          </div>
                          {lg.note && <div className="fh-tl-note">{lg.note}</div>}
                          {lg.who && <div className="fh-tl-meta">by {lg.who}</div>}
                        </div>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
            </div>
          </div>
        </div>
      )}
    </FacultyLayout>
  );
}
