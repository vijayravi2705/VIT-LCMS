// src/pages/faculty/FacultyProfile.jsx
import React, { useEffect, useMemo, useState } from "react";
import "../assets/styles/facultyProfile.css";
import { useNavigate } from "react-router-dom";
import FacultyLayout from "../layouts/FacultyLayout";
import {
    UserRound,
    Mail,
    Phone,
    Building2,
    MapPin,
    GraduationCap,
    Calendar,
    Edit3,
    Save,
    X,
    UploadCloud,
    ShieldCheck,
    FileText,
    PieChart,
    History,
    Star,
    CheckCircle2,
    AlertTriangle,
} from "lucide-react";

const DEFAULT_FACULTY = {
    id: "FAC-2025-001",
    name: "Dr. John Doe",
    title: "Associate Professor",
    department: "Computer Science & Engineering",
    facultyEmail: "john.doe@univ.edu",
    personalEmail: "dr.johndoe@gmail.com",
    phone: "+91 98765 43210",
    officeLocation: "Academic Block B, Room 204",
    joinDate: "2017-07-10",
    expertise: ["Computer Networks", "Cybersecurity", "Distributed Systems"],
    skills: ["Student Affairs", "Incident Review", "Report Drafting", "Mediation"],
    handledBlocks: ["MH-A", "MH-B", "LH-C"],
    avatar: "",
    kpis: {
        reportsFiled: 46,
        casesResolved: 32,
        avgResolutionDays: 3.7,
        pendingReviews: 5,
    },
    responsibilities: [
        "Member, Discipline Committee",
        "Coordinator, Hostel Safety Cell",
        "Advisor, Cyber Hygiene Awareness",
    ],
    preferences: {
        notifyEmail: true,
        notifySMS: false,
        showContactOnReports: true,
    },
};

const SECTION_KEYS = ["overview", "about", "activity", "notes"];
const cls = (...xs) => xs.filter(Boolean).join(" ");
const fmtDate = (iso) =>
    new Date(iso).toLocaleDateString(undefined, {
        year: "numeric",
        month: "short",
        day: "2-digit",
    });

export default function FacultyProfile() {
    const nav = useNavigate();
    const [data, setData] = useState(DEFAULT_FACULTY);
    const [edit, setEdit] = useState(false);
    const [tab, setTab] = useState("overview");
    const [notes, setNotes] = useState(
        "Faculty private notes: keep short action points, follow-ups, and committee decisions."
    );
    const [draft, setDraft] = useState(DEFAULT_FACULTY);
    const [avatarFile, setAvatarFile] = useState(null);

    useEffect(() => {
        try {
            const raw = localStorage.getItem("facultyProfile:john.doe");
            if (raw) {
                const parsed = JSON.parse(raw);
                setData({ ...DEFAULT_FACULTY, ...parsed });
                setDraft({ ...DEFAULT_FACULTY, ...parsed });
            }
            const n = localStorage.getItem("facultyProfile:john.doe:notes");
            if (n) setNotes(n);
        } catch { }
    }, []);

    const initials = useMemo(() => {
        const chunks = (data.name || "").split(" ").filter(Boolean);
        return (chunks[0]?.[0] || "") + (chunks[1]?.[0] || "");
    }, [data.name]);

    const recent = useMemo(
        () => [
            {
                id: "CMP-MH-A-101-20250901-1030-01",
                title: "Power trip in Block A",
                when: "2025-10-10T10:52:00",
                type: "Report Filed",
                status: "Submitted",
            },
            {
                id: "CMP-LH-C-319-20250903-1550-02",
                title: "Water leakage in washroom",
                when: "2025-10-09T16:24:00",
                type: "Reviewed",
                status: "In Review",
            },
            {
                id: "CMP-MH-B-212-20250907-1145-03",
                title: "Ragging incident near foyer",
                when: "2025-10-05T09:10:00",
                type: "Resolution",
                status: "Resolved",
            },
            {
                id: "CMP-LH-D-120-20250909-0910-04",
                title: "Mess food hygiene check",
                when: "2025-09-28T14:18:00",
                type: "Report Filed",
                status: "In Progress",
            },
        ],
        []
    );

    const toggleEdit = () => {
        setDraft(data);
        setEdit((e) => !e);
    };

    const updateField = (key, val) => setDraft((d) => ({ ...d, [key]: val }));

    const updatePrefs = (key, val) =>
        setDraft((d) => ({
            ...d,
            preferences: { ...d.preferences, [key]: val },
        }));

    const push = (arrKey, val) =>
        setDraft((d) => ({
            ...d,
            [arrKey]: Array.from(new Set([...(d[arrKey] || []), val].filter(Boolean))),
        }));

    const removeFrom = (arrKey, index) =>
        setDraft((d) => ({
            ...d,
            [arrKey]: (d[arrKey] || []).filter((_, i) => i !== index),
        }));

    const onAvatarPick = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setAvatarFile(file);
        const reader = new FileReader();
        reader.onload = () => {
            updateField("avatar", reader.result || "");
        };
        reader.readAsDataURL(file);
    };

    const validate = () => {
        const errors = [];
        if (!draft.name?.trim()) errors.push("Name is required.");
        if (!draft.department?.trim()) errors.push("Department is required.");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.facultyEmail)) errors.push("Faculty email looks invalid.");
        if (!draft.phone?.trim()) errors.push("Phone number is required.");
        return errors;
    };

    const onSave = () => {
        const errs = validate();
        if (errs.length) {
            alert("Please fix:\n• " + errs.join("\n• "));
            return;
        }
        setData(draft);
        localStorage.setItem("facultyProfile:john.doe", JSON.stringify(draft));
        localStorage.setItem("facultyProfile:john.doe:notes", notes || "");
        setEdit(false);
        alert("Profile saved.");
    };

    const goComplaints = () => nav("/faculty/complaints");
    const goReport = () => nav("/faculty/report");
    const goAnalytics = () => nav("/faculty/analytics");
    const goHistory = () => nav("/faculty/history");

    return (
        <FacultyLayout>
            <div className="fp-wrap">
                <header className="fp-head">
                    <div className="fp-head-left">
                        <div className="fp-avatar">
                            {data.avatar ? (
                                <img src={data.avatar} alt={data.name} />
                            ) : (
                                <div className="fp-avatar-badge">{initials.toUpperCase()}</div>
                            )}
                            <label className="fp-upload-btn" title="Upload avatar">
                                <UploadCloud size={16} />
                                <input type="file" accept="image/*" onChange={onAvatarPick} />
                            </label>
                        </div>

                        <div className="fp-title-block">
                            <h1 className="fp-name">
                                <UserRound size={18} />
                                <span>{data.name}</span>
                            </h1>
                            <p className="fp-title">
                                <GraduationCap size={16} />
                                <span>
                                    {data.title} · {data.department}
                                </span>
                            </p>

                            <div className="fp-meta">
                                <span className="fp-meta-chip">
                                    <Calendar size={14} />
                                    Joined {fmtDate(data.joinDate)}
                                </span>
                                <span className="fp-meta-chip">
                                    <Building2 size={14} />
                                    Faculty ID: {data.id}
                                </span>

                            </div>
                        </div>
                    </div>

                    <div className="fp-actions">
                        {!edit ? (
                            <>
                                <button className="btn ghost" onClick={goAnalytics}>
                                    <PieChart size={16} />
                                    Analytics
                                </button>
                                <button className="btn ghost" onClick={goHistory}>
                                    <History size={16} />
                                    History
                                </button>
                                <button className="btn ghost" onClick={goComplaints}>
                                    <FileText size={16} />
                                    Complaints
                                </button>
                                <button className="btn primary" onClick={goReport}>
                                    <FileText size={16} />
                                    File Report
                                </button>
                                <button className="btn soft" onClick={toggleEdit}>
                                    <Edit3 size={16} />
                                    Edit
                                </button>
                            </>
                        ) : (
                            <>
                                <button className="btn soft danger" onClick={() => setEdit(false)}>
                                    <X size={16} />
                                    Cancel
                                </button>
                                <button className="btn primary" onClick={onSave}>
                                    <Save size={16} />
                                    Save
                                </button>
                            </>
                        )}
                    </div>
                </header>

                <section className="fp-kpi-grid">
                    <KPI label="Reports Filed" value={data.kpis.reportsFiled} icon={<FileText size={18} />} />
                    <KPI label="Cases Resolved" value={data.kpis.casesResolved} tone="ok" icon={<CheckCircle2 size={18} />} />
                    <KPI label="Avg. Resolution (days)" value={data.kpis.avgResolutionDays} icon={<Star size={18} />} />
                    <KPI label="Pending Reviews" value={data.kpis.pendingReviews} tone="warn" icon={<AlertTriangle size={18} />} />
                </section>

                <nav className="fp-tabs">
                    {SECTION_KEYS.map((k) => (
                        <button key={k} className={cls("fp-tab", tab === k && "active")} onClick={() => setTab(k)}>
                            {k === "overview" && "Overview"}
                            {k === "about" && "About & Contact"}
                            {k === "activity" && "Activity"}
                            {k === "notes" && "Faculty Notes"}
                        </button>
                    ))}
                </nav>

                {tab === "overview" && (
                    <div className="fp-grid-2">
                        <div className="fp-card">
                            <h3 className="fp-card-title">Responsibilities</h3>
                            <ul className="fp-list">
                                {data.responsibilities.map((r, i) => (
                                    <li key={i} className="fp-list-row">
                                        <span className="dot" />
                                        <span>{r}</span>
                                    </li>
                                ))}
                            </ul>
                            {edit && (
                                <div className="fp-edit-line">
                                    <input
                                        className="fp-input"
                                        placeholder="Add a responsibility"
                                        onKeyDown={(e) => {
                                            if (e.key === "Enter") {
                                                const v = e.currentTarget.value.trim();
                                                if (v) {
                                                    push("responsibilities", v);
                                                    e.currentTarget.value = "";
                                                }
                                            }
                                        }}
                                    />
                                </div>
                            )}
                        </div>

                    </div>
                )}

                {tab === "about" && (
                    <div className="fp-grid-2">
                        <div className="fp-card">
                            <h3 className="fp-card-title">Contact & Identity</h3>
                            <div className="fp-form-grid">
                                <Field
                                    icon={<UserRound size={16} />}
                                    label="Full Name"
                                    value={(edit ? draft : data).name}
                                    onChange={(v) => edit && updateField("name", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<GraduationCap size={16} />}
                                    label="Title"
                                    value={(edit ? draft : data).title}
                                    onChange={(v) => edit && updateField("title", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<Building2 size={16} />}
                                    label="Department"
                                    value={(edit ? draft : data).department}
                                    onChange={(v) => edit && updateField("department", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<Mail size={16} />}
                                    label="Faculty Email"
                                    value={(edit ? draft : data).facultyEmail}
                                    onChange={(v) => edit && updateField("facultyEmail", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<Mail size={16} />}
                                    label="Personal Email"
                                    value={(edit ? draft : data).personalEmail}
                                    onChange={(v) => edit && updateField("personalEmail", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<Phone size={16} />}
                                    label="Phone"
                                    value={(edit ? draft : data).phone}
                                    onChange={(v) => edit && updateField("phone", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<MapPin size={16} />}
                                    label="Office Location"
                                    value={(edit ? draft : data).officeLocation}
                                    onChange={(v) => edit && updateField("officeLocation", v)}
                                    disabled={!edit}
                                />
                                <Field
                                    icon={<Calendar size={16} />}
                                    label="Join Date"
                                    type="date"
                                    value={(edit ? draft : data).joinDate}
                                    onChange={(v) => edit && updateField("joinDate", v)}
                                    disabled={!edit}
                                />
                            </div>
                        </div>

                        <div className="fp-card">
                            <h3 className="fp-card-title">Quick Actions</h3>
                            <div className="fp-actions-quick">
                                <button className="btn ghost" onClick={goComplaints}>
                                    <FileText size={16} />
                                    View Complaints
                                </button>
                                <button className="btn ghost" onClick={goReport}>
                                    <FileText size={16} />
                                    File New Report
                                </button>
                                <button className="btn ghost" onClick={goAnalytics}>
                                    <PieChart size={16} />
                                    Analytics
                                </button>
                                <button className="btn ghost" onClick={goHistory}>
                                    <History size={16} />
                                    History
                                </button>
                            </div>
                            <div className="fp-hint">Changes you make here are visible only to authorized faculty/wardens.</div>
                        </div>
                    </div>
                )}

                {tab === "activity" && (
                    <div className="fp-card">
                        <h3 className="fp-card-title">Recent Activity</h3>
                        <div className="fp-timeline">
                            {recent.map((r) => (
                                <div key={r.id} className="fp-tl-row">
                                    <div className={cls("fp-tl-dot", r.status.toLowerCase().replace(" ", "-"))} />
                                    <div className="fp-tl-card">
                                        <div className="fp-tl-top">
                                            <div className="fp-tl-title">{r.title}</div>
                                            <span className={cls("pill", r.status.toLowerCase().replace(" ", "-"))}>{r.status}</span>
                                        </div>
                                        <div className="fp-tl-sub">ID: {r.id}</div>
                                        <div className="fp-tl-meta">{new Date(r.when).toLocaleString()}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {tab === "notes" && (
                    <div className="fp-card">
                        <h3 className="fp-card-title">Faculty Notes (Private)</h3>
                        <textarea
                            className="fp-notes"
                            rows={8}
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            placeholder="Add internal notes (not visible to students)…"
                        />
                        <div className="fp-notes-actions">
                            <button
                                className="btn soft"
                                onClick={() => {
                                    localStorage.setItem("facultyProfile:john.doe:notes", notes || "");
                                    alert("Notes saved.");
                                }}
                            >
                                <Save size={16} />
                                Save Notes
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </FacultyLayout>
    );
}

function KPI({ label, value, tone = "base", icon }) {
    return (
        <div className={cls("fp-kpi", `tone--${tone}`)}>
            <div className="fp-kpi-top">
                <span className="fp-kpi-icon">{icon}</span>
                <span className="fp-kpi-label">{label}</span>
            </div>
            <div className="fp-kpi-value">{value}</div>
        </div>
    );
}

function Tag({ text, onRemove }) {
    return (
        <span className="fp-tag">
            {text}
            {onRemove && (
                <button className="fp-tag-x" onClick={onRemove} aria-label="Remove tag">
                    <X size={12} />
                </button>
            )}
        </span>
    );
}

function Pref({ label, checked, onChange }) {
    return (
        <label className="fp-pref">
            <input type="checkbox" checked={!!checked} onChange={(e) => onChange?.(e.target.checked)} />
            <span className="fp-switch" />
            <span className="fp-pref-label">{label}</span>
        </label>
    );
}

function Field({ icon, label, value, onChange, disabled, type = "text" }) {
    return (
        <label className={cls("fp-field", disabled && "disabled")}>
            <span className="fp-field-label">
                {icon}
                {label}
            </span>
            <input
                className="fp-input"
                type={type}
                value={value || ""}
                onChange={(e) => onChange?.(e.target.value)}
                disabled={disabled}
            />
        </label>
    );
}
