import React, { useEffect, useMemo, useRef, useState } from "react";
import "../assets/styles/facultyadmin.css";
import api from "../../utils/api";
import FacultyLayout from "../layouts/FacultyLayout";

const pad = (n) => String(n).padStart(2, "0");
const ts = () => {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
};

export default function FacultyAdmin() {
  const [loading, setLoading] = useState(true);
  const [flag, setFlag] = useState(0);
  const [email, setEmail] = useState("");
  const [step, setStep] = useState("otp");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);
  const otpRefs = useRef([...Array(6)].map(() => React.createRef()));

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const r = await api.get("/faculty/admin/flag");
        if (!mounted) return;
        setFlag(Number(r.data?.faculty_admin || 0));
        setEmail(r.data?.email || "");
        setStep(Number(r.data?.faculty_admin) === 1 ? "otp" : "locked");
      } catch {
        if (!mounted) return;
        setFlag(0);
        setStep("locked");
      }
      setLoading(false);
    })();
    return () => (mounted = false);
  }, []);

  const otpValue = useMemo(() => otp.join(""), [otp]);

  const sendOtp = async () => {
    setBusy(true);
    try {
      await api.post("/faculty/admin/otp/send");
      setToast({ title: "OTP sent", desc: `Check ${email || "your email"}` });
    } catch {
      setToast({ title: "Failed to send OTP", desc: "Try again." });
    }
    setBusy(false);
  };

  const verifyOtp = async () => {
    if (otpValue.length !== 6) return;
    setBusy(true);
    try {
      const r = await api.post("/faculty/admin/otp/verify", { code: otpValue });
      if (r.data?.ok) {
        setStep("ready");
        setToast({ title: "Verified", desc: "Admin access unlocked." });
      } else {
        setToast({ title: "Invalid OTP", desc: "Recheck and try again." });
      }
    } catch {
      setToast({ title: "Invalid OTP", desc: "Recheck and try again." });
    }
    setBusy(false);
  };

  const handleOtp = (i, v) => {
    if (!/^\d?$/.test(v)) return;
    const next = [...otp];
    next[i] = v;
    setOtp(next);
    if (v && otpRefs.current[i + 1]) otpRefs.current[i + 1].current?.focus();
  };

  const clearOtp = () => {
    setOtp(["", "", "", "", "", ""]);
    otpRefs.current[0].current?.focus();
  };

  const Section = ({ title, children, className = "" }) => (
    <div className={`fad-card ${className}`}>
      <h3>{title}</h3>
      {children}
    </div>
  );

  if (loading) {
    return (
      <FacultyLayout>
        <div className="fad-page">
          <div className="fad-header">
            <div>
              <h1 className="fad-title">Faculty Admin</h1>
              <p className="fad-sub">Loading…</p>
            </div>
          </div>
          <div className="fad-grid-3">
            <div className="fad-card"><div className="fad-skeleton fad-h-120" /></div>
            <div className="fad-card"><div className="fad-skeleton fad-h-120" /></div>
            <div className="fad-card"><div className="fad-skeleton fad-h-120" /></div>
          </div>
        </div>
      </FacultyLayout>
    );
  }

  if (step === "locked" || flag !== 1) {
    return (
      <FacultyLayout>
        <div className="fad-page">
          <div className="fad-header">
            <div>
              <h1 className="fad-title">Faculty Admin</h1>
              <p className="fad-sub">Restricted. Only admin-enabled faculty can access.</p>
            </div>
          </div>
          <div className="fad-empty">
            <div>No admin access for this account.</div>
          </div>
        </div>
      </FacultyLayout>
    );
  }

  if (step === "otp") {
    return (
      <FacultyLayout>
        <div className="fad-page">
          <div className="fad-header">
            <div>
              <h1 className="fad-title">Faculty Admin</h1>
              <p className="fad-sub">Step-up verification required.</p>
            </div>
            <div className="fad-actions">
              <button className="fad-export" onClick={sendOtp} disabled={busy}>Send OTP</button>
            </div>
          </div>

          <div className="fa-otp-wrap fad-card">
            <div className="fa-otp-head">
              <div className="fa-otp-title">Enter OTP</div>
              <div className="fa-otp-sub">{email ? `Sent to ${email}` : "Check your email"}</div>
            </div>
            <div className="fa-otp-boxes">
              {otp.map((d, i) => (
                <input
                  key={i}
                  ref={otpRefs.current[i]}
                  className="fa-otp-input"
                  inputMode="numeric"
                  maxLength={1}
                  value={d}
                  onChange={(e) => handleOtp(i, e.target.value)}
                />
              ))}
            </div>
            <div className="fa-otp-actions">
              <button className="fa-btn ghost" onClick={clearOtp}>Clear</button>
              <button className="fa-btn primary" onClick={verifyOtp} disabled={busy || otpValue.length !== 6}>
                Verify
              </button>
            </div>
          </div>

          {toast ? (
            <div className="fad-toast">
              <div className="title">{toast.title}</div>
              <div className="desc">{toast.desc}</div>
            </div>
          ) : null}
        </div>
      </FacultyLayout>
    );
  }

  return (
    <FacultyLayout>
      <div className="fad-page">
        <div className="fad-header">
          <div>
            <h1 className="fad-title">Faculty Admin</h1>
            <p className="fad-sub">Privileged controls • {ts()}</p>
          </div>
        </div>

        <div className="fad-kpis">
          <div className="fad-kpi fad-kpi-blue"><div>Total Users</div><div>—</div></div>
          <div className="fad-kpi fad-kpi-indigo"><div>Open Complaints</div><div>—</div></div>
          <div className="fad-kpi fad-kpi-amber"><div>Emergencies</div><div>—</div></div>
          <div className="fad-kpi fad-kpi-green"><div>Resolved (24h)</div><div>—</div></div>
        </div>

        <div className="fad-grid-3">
          <Section title="Global Controls">
            <div className="fa-actions">
              <button className="fa-btn primary">Force Assign</button>
              <button className="fa-btn">Escalate</button>
              <button className="fa-btn">Close</button>
              <button className="fa-btn danger">Reject</button>
            </div>
            <div className="fa-row">
              <input className="fa-input" placeholder="Complaint ID" />
              <input className="fa-input" placeholder="Target Block (e.g., MH-A)" />
            </div>
          </Section>

          <Section title="Emergency Monitor">
            <div className="fa-list scroll">
              <div className="fa-item">
                <span className="fad-badge danger">Emergency</span>
                <div className="fa-item-meta">—</div>
              </div>
            </div>
          </Section>

          <Section title="Users & Roles">
            <div className="fa-row">
              <input className="fa-input" placeholder="Search username or VIT ID" />
              <button className="fa-btn">Search</button>
            </div>
            <div className="fa-table-wrap">
              <table className="fad-table">
                <thead>
                  <tr className="fad-tr">
                    <th className="fad-th">ID</th>
                    <th className="fad-th">Username</th>
                    <th className="fad-th">VIT ID</th>
                    <th className="fad-th">Active</th>
                    <th className="fad-th">Roles</th>
                    <th className="fad-th"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="fad-tr">
                    <td className="fad-td">—</td>
                    <td className="fad-td">—</td>
                    <td className="fad-td">—</td>
                    <td className="fad-td">—</td>
                    <td className="fad-td">—</td>
                    <td className="fad-td"><button className="fa-btn ghost">Edit</button></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Section>

          <Section title="Audit Logs" className="fa-span-2">
            <div className="fa-list scroll">
              <div className="fa-item">
                <div className="fa-item-title">—</div>
                <div className="fa-item-meta">—</div>
              </div>
            </div>
          </Section>

          <Section title="Settings">
            <div className="fa-actions">
              <button className="fa-btn">Blocks</button>
              <button className="fa-btn">Categories</button>
              <button className="fa-btn">Severity</button>
              <button className="fa-btn">RBAC</button>
            </div>
          </Section>
        </div>

        {toast ? (
          <div className="fad-toast">
            <div className="title">{toast.title}</div>
            <div className="desc">{toast.desc}</div>
          </div>
        ) : null}
      </div>
    </FacultyLayout>
  );
}
