import React, { useMemo, useState } from "react";
import "../assets/styles/wardend.css";
import WardenLayout from "../layouts/WardenLayout";

/* --------------------------------------------------------------------------
   Logged-in Warden (to be replaced with actual auth/session info)
-------------------------------------------------------------------------- */
const CURRENT_WARDEN = { id: "W1", name: "Ms. Priya Rao" };

/* --------------------------------------------------------------------------
   Mock: Faculty → Warden Escalations (replace with backend API later)
-------------------------------------------------------------------------- */
const FAC_ESCALATIONS = [
  {
    reportId: "FAC-20251012-1905",
    title: "Assault reported near MH B-217",
    status: "Submitted",
    priority: "Emergency",
    submittedAt: "2025-10-12 19:05",
    toWardenId: "W1",
    fromRole: "faculty",
    facultyId: "F2",
    facultyName: "Dr. A. Meera",
    place: "MH B-217",
  },
  {
    reportId: "FAC-20251013-1630",
    title: "Injury during football match",
    status: "Resolved",
    priority: "High",
    submittedAt: "2025-10-13 16:30",
    toWardenId: "W2",
    fromRole: "faculty",
    facultyId: "F1",
    facultyName: "Dr. John Doe",
    place: "Football Ground",
  },
  {
    reportId: "FAC-20251015-1415",
    title: "Unfair grading concern (student altercation after)",
    status: "In Review",
    priority: "Medium",
    submittedAt: "2025-10-15 14:15",
    toWardenId: "W1",
    fromRole: "faculty",
    facultyId: "F1",
    facultyName: "Dr. John Doe",
    place: "Academic Block 3",
  },
];

const cap = (s = "") => s.charAt(0).toUpperCase() + s.slice(1);
const priClass = (p) => `wdd-chip ${String(p || "").toLowerCase()}`;

export default function WardenMyEscalations({ currentWardenId = CURRENT_WARDEN.id }) {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [priority, setPriority] = useState("");

  // Filter only this warden’s escalations
  const mine = useMemo(
    () =>
      FAC_ESCALATIONS.filter(
        (c) => c.fromRole === "faculty" && c.toWardenId === currentWardenId
      ),
    [currentWardenId]
  );

  // Apply search and filters
  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return mine.filter((c) => {
      const okQ =
        !t ||
        (c.title || "").toLowerCase().includes(t) ||
        (c.reportId || "").toLowerCase().includes(t) ||
        (c.place || "").toLowerCase().includes(t) ||
        (c.facultyName || "").toLowerCase().includes(t) ||
        (c.status || "").toLowerCase().includes(t) ||
        (c.priority || "").toLowerCase().includes(t);
      const okS = !status || c.status === status;
      const okP = !priority || c.priority === priority;
      return okQ && okS && okP;
    });
  }, [mine, q, status, priority]);

  return (
    <WardenLayout>
      <div className="wdd-page">
        <header className="wdd-head">
          <div>
            <h1 className="wdd-title">My Faculty Escalations</h1>
            <p className="wdd-sub">
              Complaints escalated by faculty to you ({currentWardenId}). Replace the
              mock data with your backend API.
            </p>
          </div>
        </header>

        {/* Filters */}
        <section className="wdd-filter">
          <input
            className="wdd-input"
            placeholder="Search title / ID / place / faculty / status / priority…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <select
            className="wdd-select"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">All Statuses</option>
            <option>Submitted</option>
            <option>In Review</option>
            <option>In Progress</option>
            <option>Resolved</option>
            <option>Rejected</option>
          </select>
          <select
            className="wdd-select"
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
          >
            <option value="">All Priorities</option>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
            <option>Emergency</option>
          </select>
        </section>

        {/* Complaint Cards */}
        <section className="wdd-cards">
          {list.map((c) => (
            <div key={c.reportId} className="wdd-card">
              <div className="wdd-avatar">
                {(c.facultyName || "?")
                  .split(" ")
                  .map((s) => s[0])
                  .slice(0, 2)
                  .join("")
                  .toUpperCase()}
              </div>

              <div className="wdd-main">
                <div className="wdd-name">{c.title}</div>
                <div className="wdd-sub">
                  <span className="wdd-id">{c.reportId}-</span>
             
                  <span>{c.place || "—"}-</span>
                  
                  <span>By: {c.facultyName || c.facultyId}</span>
                </div>
                <div className="wdd-meta">
                  <span className={priClass(c.priority)}>{cap(c.priority)}</span>
                  <span className="wdd-chip tone-status">{c.status}</span>
                  <span className="wdd-chip">{c.submittedAt}</span>
                </div>
              </div>

              <div className="wdd-actions">
                <button
                  className="wdd-btn ghost"
                  onClick={() => alert(`Open complaint ${c.reportId} (stub)`)}
                >
                  Open
                </button>
                <button
                  className="wdd-btn primary"
                  onClick={() => alert(`Acknowledge ${c.reportId} (stub)`)}
                >
                  Acknowledge
                </button>
              </div>
            </div>
          ))}

          {!list.length && (
            <div className="wdd-empty">
              {mine.length
                ? "No results match your filters/search."
                : "No faculty escalations have been assigned to you yet."}
            </div>
          )}
        </section>
      </div>
    </WardenLayout>
  );
}
