import React, { useMemo, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/styles/wardendash.css";
import WardenLayout from "../layouts/WardenLayout";

import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid
} from "recharts";

function useSmoothScroll() {
  const ref = useRef(null);
  const scrollBy = (d) => ref.current?.scrollBy({ top: d, behavior: "smooth" });
  const toTop = () => ref.current?.scrollTo({ top: 0, behavior: "smooth" });
  const toBottom = () => {
    const el = ref.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  };
  return { ref, scrollBy, toTop, toBottom };
}

export default function WardenDashboard() {
  const navigate = useNavigate();

  const complaints = [
    { id: "CMP-MH-A-101-20250901-1030-01", title: "Power trip in Block A", category: "Maintenance", status: "In Review", priority: "high", updatedAt: "2025-10-12T21:10:00" },
    { id: "CMP-LH-C-319-20250903-1550-02", title: "Water leakage in washroom", category: "Maintenance", status: "In Progress", priority: "emergency", updatedAt: "2025-10-13T10:15:00" },
    { id: "CMP-MH-B-212-20250907-1145-03", title: "Ragging incident near foyer", category: "Safety", status: "In Review", priority: "emergency", updatedAt: "2025-10-14T08:30:00" },
    { id: "CMP-LH-D-120-20250909-0910-04", title: "Mess food hygiene check", category: "Food", status: "Resolved", priority: "medium", updatedAt: "2025-10-13T16:05:00" },
    { id: "CMP-MH-A-005-20250910-1740-05", title: "Wi-Fi not working", category: "Maintenance", status: "Submitted", priority: "low", updatedAt: "2025-10-12T14:50:00" },
    { id: "CMP-LH-B-404-20250911-1210-06", title: "Harassment complaint", category: "Safety", status: "In Progress", priority: "emergency", updatedAt: "2025-10-14T09:45:00" },
    { id: "CMP-MH-A-230-20250912-1830-07", title: "Noise after hours", category: "Discipline", status: "Resolved", priority: "high", updatedAt: "2025-10-10T19:00:00" },
  ];

  const metrics = useMemo(() => {
    const awaiting = complaints.filter(c => ["Submitted", "In Review"].includes(c.status));
    const resolved = complaints.filter(c => c.status === "Resolved");
    const pending = complaints.filter(c => ["Submitted", "In Review", "In Progress"].includes(c.status));
    return { awaitingAction: awaiting.length, resolved: resolved.length, pending: pending.length, total: complaints.length };
  }, [complaints]);

  const statusBreakdown = useMemo(() => {
    const groups = ["Submitted", "In Review", "In Progress", "Resolved"];
    return groups.map(g => ({ name: g, value: complaints.filter(c => c.status === g).length }));
  }, [complaints]);

  const categoryBreakdown = useMemo(() => {
    const m = new Map();
    complaints.forEach(c => m.set(c.category, (m.get(c.category) || 0) + 1));
    return Array.from(m, ([name, value]) => ({ name, value }));
  }, [complaints]);

  const emergencyRecent = useMemo(
    () => complaints.filter(c => c.priority === "emergency").sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)),
    [complaints]
  );

  const { ref: pageRef } = useSmoothScroll();
  const go = (p) => navigate(p);
  const COLORS = ["#60a5fa", "#22c55e", "#f59e0b", "#ef4444"];

  return (
    <WardenLayout scrollRef={pageRef}>
      <div className="wdds-wrapper" role="main" aria-label="Warden dashboard">
        <div className="wdds-head">
          <div>
            <h1 className="wdds-title">Warden Dashboard</h1>
            <p className="wdds-sub">Quick view of reports, actions and emergency cases.</p>
          </div>
          <div className="wdds-actions">
            <button className="wdds-primary" onClick={() => go("/warden/report")}>+ File New Report</button>
            <button className="wdds-ghost" onClick={() => go("/warden/complaints")}>View All Complaints</button>
          </div>
        </div>

        <div className="wdds-kpis">
          <div className="kpi-card clickable"><div className="kpi-label">Pending / In Review</div><div className="kpi-value">{metrics.pending}</div><div className="kpi-meta">Items not resolved</div></div>
          <div className="kpi-card clickable"><div className="kpi-label">Awaiting My Action</div><div className="kpi-value">{metrics.awaitingAction}</div><div className="kpi-meta">Needs review/approval</div></div>
          <div className="kpi-card clickable"><div className="kpi-label">Resolved Cases</div><div className="kpi-value">{metrics.resolved}</div><div className="kpi-meta">Closed successfully</div></div>
          <div className="kpi-card clickable"><div className="kpi-label">Total Complaints</div><div className="kpi-value">{metrics.total}</div><div className="kpi-meta">Across blocks</div></div>
        </div>

        <div className="wdds-charts">
          <div className="wdds-card">
            <div className="wdds-card-head"><h3>Status Breakdown</h3></div>
            <div className="wdds-chart-body">
              <ResponsiveContainer width="100%" height={280}>
                <PieChart margin={{ top: 16, right: 50, bottom: 16, left: 50 }}>
                  <Pie data={statusBreakdown} dataKey="value" cx="50%" cy="50%" outerRadius={76} labelLine={false} label={({ name, value }) => `${name}: ${value}`}>
                    {statusBreakdown.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip /><Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="wdds-card">
            <div className="wdds-card-head"><h3>Complaints by Category</h3></div>
            <div className="wdds-chart-body">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={categoryBreakdown} barSize={36}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} fill="url(#barGradient)" />
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#2563eb" />
                      <stop offset="100%" stopColor="#00c6ff" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <br />
        <div className="wdds-card wdds-table" aria-label="Emergency – Recently Updated">
          <div className="wdds-card-head">
            <h3>Emergency – Recently Updated</h3>
            <span className="wdds-muted">Latest first • High priority only</span>
          </div>
          <div className="wdds-table-scroll">
            <table>
              <thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Status</th><th>Updated</th></tr></thead>
              <tbody>
                {emergencyRecent.map(c => (
                  <tr key={c.id} className="row-link" onClick={() => go(`/warden/complaints?focus=${encodeURIComponent(c.id)}`)}>
                    <td className="mono">{c.id.slice(0, 12)}…</td>
                    <td>{c.title}</td>
                    <td><span className="chip">{c.category}</span></td>
                    <td><span className={`pill ${c.status.replace(" ", "-").toLowerCase()}`}>{c.status}</span></td>
                    <td className="muted">{new Date(c.updatedAt).toLocaleString()}</td>
                  </tr>
                ))}
                {emergencyRecent.length === 0 && (<tr><td colSpan="5" style={{ textAlign: "center" }}>No emergency cases 🎉</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </WardenLayout>
  );
}
