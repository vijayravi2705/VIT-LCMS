import React, { useMemo, useState, useRef } from "react";
import {
  ResponsiveContainer,
  LineChart, Line,
  CartesianGrid, XAxis, YAxis, Tooltip, Legend,
  AreaChart, Area,
  BarChart, Bar,
  PieChart, Pie, Cell,
  ReferenceLine,
} from "recharts";
import "../assets/styles/wardenanalytics.css";
import WardenLayout from "../layouts/WardenLayout";

/**
 * Warden Analytics
 * - Mock data is scoped to a typical month; swap with API later.
 * - Uses wda- class namespace (day colors / tight UI).
 */
export default function WardenAnalytics() {
  const [range, setRange] = useState("Last 30 Days");
  const pageRef = useRef(null);

  /** ---------------- Mock datasets (swap with backend) ---------------- */
  // Daily timeline (totals / resolved / emergency)
  const timeline = useMemo(
    () => [
      { day: "10/01", total: 18, resolved: 7, inprog: 8, rejected: 3, emergency: 2, fromFaculty: 6, fromBlocks: 12, avgHrsToResolve: 44 },
      { day: "10/03", total: 22, resolved: 9, inprog: 9, rejected: 4, emergency: 3, fromFaculty: 7, fromBlocks: 15, avgHrsToResolve: 40 },
      { day: "10/05", total: 16, resolved: 10, inprog: 4, rejected: 2, emergency: 1, fromFaculty: 4, fromBlocks: 12, avgHrsToResolve: 30 },
      { day: "10/07", total: 24, resolved: 13, inprog: 9, rejected: 2, emergency: 2, fromFaculty: 9, fromBlocks: 15, avgHrsToResolve: 28 },
      { day: "10/09", total: 19, resolved: 12, inprog: 4, rejected: 3, emergency: 1, fromFaculty: 5, fromBlocks: 14, avgHrsToResolve: 26 },
      { day: "10/11", total: 21, resolved: 15, inprog: 4, rejected: 2, emergency: 2, fromFaculty: 8, fromBlocks: 13, avgHrsToResolve: 22 },
      { day: "10/13", total: 20, resolved: 12, inprog: 6, rejected: 2, emergency: 2, fromFaculty: 6, fromBlocks: 14, avgHrsToResolve: 24 },
      { day: "10/15", total: 27, resolved: 18, inprog: 6, rejected: 3, emergency: 3, fromFaculty: 9, fromBlocks: 18, avgHrsToResolve: 21 },
      { day: "10/17", total: 23, resolved: 15, inprog: 6, rejected: 2, emergency: 2, fromFaculty: 7, fromBlocks: 16, avgHrsToResolve: 23 },
      { day: "10/19", total: 25, resolved: 19, inprog: 4, rejected: 2, emergency: 2, fromFaculty: 8, fromBlocks: 17, avgHrsToResolve: 20 },
      { day: "10/21", total: 18, resolved: 11, inprog: 5, rejected: 2, emergency: 1, fromFaculty: 5, fromBlocks: 13, avgHrsToResolve: 27 },
      { day: "10/23", total: 26, resolved: 20, inprog: 4, rejected: 2, emergency: 2, fromFaculty: 10, fromBlocks: 16, avgHrsToResolve: 19 },
      { day: "10/25", total: 22, resolved: 16, inprog: 4, rejected: 2, emergency: 2, fromFaculty: 7, fromBlocks: 15, avgHrsToResolve: 22 },
      { day: "10/27", total: 24, resolved: 17, inprog: 5, rejected: 2, emergency: 2, fromFaculty: 8, fromBlocks: 16, avgHrsToResolve: 21 },
      { day: "10/29", total: 20, resolved: 14, inprog: 4, rejected: 2, emergency: 1, fromFaculty: 6, fromBlocks: 14, avgHrsToResolve: 23 },
    ],
    []
  );

  // Status totals (aggregate for stacked bar)
  const statusByWeek = useMemo(
    () => [
      { label: "Wk1", resolved: 29, inprog: 31, rejected: 10, emergency: 7 },
      { label: "Wk2", resolved: 39, inprog: 20, rejected: 7,  emergency: 6 },
      { label: "Wk3", resolved: 34, inprog: 19, rejected: 6,  emergency: 6 },
      { label: "Wk4", resolved: 41, inprog: 18, rejected: 7,  emergency: 7 },
    ],
    []
  );

  // Source distribution
  const sources = useMemo(
    () => [
      { name: "From Faculty", value: timeline.reduce((a, b) => a + b.fromFaculty, 0) },
      { name: "From Blocks",  value: timeline.reduce((a, b) => a + b.fromBlocks,  0) },
      { name: "Other",        value: Math.max(0, timeline.reduce((a, b) => a + b.total, 0) - (timeline.reduce((a, b) => a + b.fromFaculty, 0) + timeline.reduce((a, b) => a + b.fromBlocks, 0))) },
    ],
    [timeline]
  );

  // Per-block volume (swap with your scoped blocks)
  const byBlock = [
    { block: "MH-A", total: 62, resolved: 44 },
    { block: "MH-B", total: 48, resolved: 36 },
    { block: "LH-C", total: 27, resolved: 21 },
    { block: "MH-D", total: 19, resolved: 14 },
  ];

  /** ---------------- KPIs ---------------- */
  const kpi = useMemo(() => {
    const totals = timeline.reduce(
      (acc, d) => ({
        total: acc.total + d.total,
        resolved: acc.resolved + d.resolved,
        inprog: acc.inprog + d.inprog,
        rejected: acc.rejected + d.rejected,
        emergency: acc.emergency + d.emergency,
        fromFaculty: acc.fromFaculty + d.fromFaculty,
        fromBlocks: acc.fromBlocks + d.fromBlocks,
        avgHrsToResolveSum: acc.avgHrsToResolveSum + d.avgHrsToResolve,
      }),
      { total: 0, resolved: 0, inprog: 0, rejected: 0, emergency: 0, fromFaculty: 0, fromBlocks: 0, avgHrsToResolveSum: 0 }
    );
    const avgResolve = Math.round(totals.avgHrsToResolveSum / timeline.length);
    const sla = Math.round((totals.resolved / Math.max(1, totals.total)) * 100);
    return { ...totals, avgResolve, sla };
  }, [timeline]);

  const COLORS = ["#2563eb", "#10b981", "#f59e0b", "#ef4444", "#6366f1", "#06b6d4"];

  /** ---------------- UI ---------------- */
  return (
    <WardenLayout>
      <div className="wda-page" ref={pageRef}>
        {/* Header */}
        <header className="wda-header">
          <div>
            <h1 className="wda-title">Warden Analytics & Insights</h1>
            <p className="wda-sub">Escalations from faculty, block activity, and outcomes for your scope.</p>
          </div>
          <div className="wda-actions">
            <select className="wda-select" value={range} onChange={(e)=>setRange(e.target.value)}>
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
              <option>Last 90 Days</option>
              <option>FY 2025</option>
            </select>
          </div>
        </header>

        {/* KPIs */}
        <section className="wda-kpis wda-kpis-wide">
          <div className="wda-kpi wda-kpi-blue"><div>Total</div><div>{kpi.total}</div></div>
          <div className="wda-kpi wda-kpi-sky"><div>From Faculty</div><div>{kpi.fromFaculty}</div></div>
          <div className="wda-kpi wda-kpi-indigo"><div>From Blocks</div><div>{kpi.fromBlocks}</div></div>

          <div className="wda-kpi wda-kpi-green"><div>Resolved</div><div>{kpi.resolved}</div></div>
          <div className="wda-kpi wda-kpi-amber"><div>In Progress</div><div>{kpi.inprog}</div></div>
          <div className="wda-kpi wda-kpi-gray"><div>Rejected</div><div>{kpi.rejected}</div></div>
          <div className="wda-kpi wda-kpi-red"><div>Emergency</div><div>{kpi.emergency}</div></div>

          <div className="wda-kpi wda-kpi-purple"><div>Avg Resolve</div><div>{kpi.avgResolve}h</div></div>
          <div className="wda-kpi wda-kpi-amber"><div>SLA %</div><div>{kpi.sla}%</div></div>
        </section>

        {/* Charts Row 1: Trend + Status */}
        <section className="wda-grid-2">
          <div className="wda-card">
            <h3>Complaints Trend</h3>
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={timeline}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" /><YAxis allowDecimals={false} />
                <Tooltip /><Legend />
                <Line dataKey="total" stroke="#2563eb" strokeWidth={2} />
                <Line dataKey="resolved" stroke="#10b981" strokeWidth={2} />
                <Line dataKey="emergency" stroke="#ef4444" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="wda-card">
            <h3>Status Breakdown (Weekly)</h3>
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={statusByWeek}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" /><YAxis allowDecimals={false} />
                <Tooltip /><Legend />
                <Bar dataKey="resolved" stackId="s" fill="#10b981" radius={[6,6,0,0]} />
                <Bar dataKey="inprog"  stackId="s" fill="#f59e0b" radius={[6,6,0,0]} />
                <Bar dataKey="rejected" stackId="s" fill="#64748b" radius={[6,6,0,0]} />
                <Bar dataKey="emergency" stackId="s" fill="#ef4444" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Charts Row 2: Sources + Resolution Velocity */}
        <section className="wda-grid-2">
          <div className="wda-card">
            <h3>Source Mix</h3>
            <ResponsiveContainer width="100%" height={320}>
              <PieChart>
                <Pie data={sources} dataKey="value" nameKey="name" outerRadius={100} label>
                  {sources.map((s, i) => <Cell key={s.name} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip /><Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="wda-card">
            <h3>Resolution Velocity</h3>
            <ResponsiveContainer width="100%" height={320}>
              <AreaChart data={timeline}>
                <defs>
                  <linearGradient id="wdaG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.06} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" /><YAxis allowDecimals={false} />
                <Tooltip />
                <ReferenceLine y={24} stroke="#94a3b8" strokeDasharray="4 4" />
                <Area dataKey="avgHrsToResolve" name="Avg Hours" stroke="#10b981" fill="url(#wdaG)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

      
      </div>
    </WardenLayout>
  );
}
