    import React, { useMemo, useState, useEffect, useRef } from "react";
    import "../assets/styles/wardencm.css";
    import WardenLayout from "../layouts/WardenLayout";

    /** ---------- Demo seed (replace with API data later) ---------- */
    const seed = [
    {
        id: "CMP-MH-A-101-20251010-2250-01",
        title: "Ragging incident",
        cat: "Safety",
        priority: "Emergency",
        status: "In Review",
        updated: "10 Oct, 22:58",
        reporterType: "student",
        reporter: "Aarav Menon",
        regno: "22BIT0346",
        reporterDept: "EEE",
        reporterContact: "+91 98XXXXXX12",
        hostelType: "MH",
        hostelBlock: "A",
        roomNumber: "101",
        submittedAt: "10 Oct, 22:50",
        location: "MH A-101",
        subcategory: "ragging",
        incidentDateTime: "2025-10-10 22:40",
        titleSubmitted: "Ragging incident",
        summary: "Verbal abuse reported near hostel A-101.",
        details:
        "Student alleged verbal abuse by seniors. CCTV corridor camera to be checked.",
        attachments: [{ name: "corridor-cam.mp4" }, { name: "statement.pdf" }],
        tags: ["ragging", "safety"],
        victims: [
        {
            name: "Aarav Menon",
            reg: "22BIT0346",
            contact: "+91 98XXXXXX12",
            description: "Verbal abuse by seniors.",
        },
        ],
        witnesses: [{ name: "Block A guard", reg: "", contact: "" }],
        accused: [{ name: "Unknown", role: "student", id: "", contact: "" }],
        assignedTo: "Dean Office",
        adminNotes: "",
    },
    {
        id: "CMP-LH-C-304-20251011-0730-01",
        title: "Suspicious outsider",
        cat: "Safety",
        priority: "High",
        status: "In Progress",
        updated: "11 Oct, 08:10",
        reporterType: "student",
        reporter: "Nisha Varma",
        regno: "22CSE1203",
        reporterDept: "CSE",
        reporterContact: "+91 9XXXXXX321",
        hostelType: "LH",
        hostelBlock: "C",
        roomNumber: "304",
        submittedAt: "11 Oct, 07:30",
        location: "LH C-304",
        subcategory: "suspicious",
        incidentDateTime: "2025-10-11 07:20",
        titleSubmitted: "Suspicious outsider",
        summary: "Unknown person loitering around lecture hall.",
        details:
        "Outsider without ID was seen near C-304. Security alerted to sweep the corridor.",
        attachments: [{ name: "photo.jpg" }],
        tags: ["outsider"],
        victims: [],
        witnesses: [{ name: "Nisha Varma", reg: "22CSE1203", contact: "" }],
        accused: [{ name: "Unknown", role: "outsider", id: "", contact: "" }],
        assignedTo: "Security Team",
        adminNotes: "",
    },
    {
        id: "CMP-MH-B-217-20251012-1905-02",
        title: "Assault reported",
        cat: "Safety",
        priority: "Emergency",
        status: "Submitted",
        updated: "12 Oct, 19:07",
        reporterType: "faculty",
        facultyId: "VIT12345",
        facultyName: "Dr. Jane Doe",
        facultyDept: "EEE",
        facultyDesignation: "Assistant Professor",
        facultyContact: "+91 9XXXXXX987",
        reporter: "Pranav S",
        regno: "22EEE2211",
        location: "MH B-217",
        submittedAt: "12 Oct, 19:05",
        subcategory: "violence",
        incidentDateTime: "2025-10-12 19:00",
        titleSubmitted: "Assault reported",
        summary: "Physical altercation between students.",
        details: "Resident tutor called. Need medical check and statements.",
        attachments: [
        { name: "med-report.png" },
        { name: "rt-note.txt" },
        { name: "cctv-clip.mp4" },
        ],
        tags: [],
        victims: [{ name: "Pranav S", reg: "22EEE2211" }],
        witnesses: [{ name: "RT on duty", reg: "", contact: "" }],
        accused: [{ name: "Unknown", role: "student", id: "", contact: "" }],
        assignedTo: "Warden Office",
        adminNotes: "",
    },
    {
        id: "CMP-MH-D-002-20251012-2100-01",
        title: "Electrical fire smell",
        cat: "Maintenance",
        priority: "High",
        status: "In Review",
        updated: "12 Oct, 21:10",
        reporterType: "student",
        reporter: "Isha Kapoor",
        regno: "22IT0687",
        reporterDept: "IT",
        reporterContact: "+91 9XXXXXX111",
        hostelType: "MH",
        hostelBlock: "D",
        roomNumber: "002",
        submittedAt: "12 Oct, 21:00",
        location: "MH D-002 (panel room)",
        subcategory: "electricity",
        incidentDateTime: "2025-10-12 20:55",
        titleSubmitted: "Electrical fire smell",
        summary: "Burning smell from panel room.",
        details: "Probable overheating of MCB. Immediate shutdown suggested.",
        attachments: [],
        tags: ["electrical", "maintenance"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Maintenance",
        adminNotes: "",
    },
    {
        id: "CMP-MH-C-115-20251014-2100-03",
        title: "Broken ceiling fan",
        cat: "Maintenance",
        priority: "Medium",
        status: "In Review",
        updated: "14 Oct, 21:10",
        reporterType: "student",
        reporter: "Rahul Raj",
        regno: "22CSE0421",
        reporterDept: "CSE",
        reporterContact: "+91 9XXXXXX123",
        hostelType: "MH",
        hostelBlock: "C",
        roomNumber: "115",
        submittedAt: "14 Oct, 21:00",
        location: "MH C-115",
        subcategory: "electrical",
        incidentDateTime: "2025-10-14 20:50",
        titleSubmitted: "Broken ceiling fan",
        summary: "Fan stopped working suddenly during night.",
        details: "Fan motor not running even after switch replacement.",
        attachments: [{ name: "fan-issue.jpg" }],
        tags: ["maintenance", "electrical"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Maintenance",
        adminNotes: "",
    },

    {
        id: "CMP-LH-B-210-20251013-1900-02",
        title: "Food poisoning after dinner",
        cat: "Food",
        priority: "High",
        status: "In Progress",
        updated: "13 Oct, 19:20",
        reporterType: "student",
        reporter: "Priya Sharma",
        regno: "22BTBIO077",
        reporterDept: "Biotech",
        reporterContact: "+91 9XXXXXX321",
        hostelType: "LH",
        hostelBlock: "B",
        roomNumber: "210",
        submittedAt: "13 Oct, 19:00",
        location: "LH Mess",
        subcategory: "food_quality",
        incidentDateTime: "2025-10-13 18:40",
        titleSubmitted: "Food poisoning after dinner",
        summary:
        "Several students felt unwell after mess dinner.",
        details:
        "Likely due to undercooked paneer curry. Medical team informed.",
        attachments: [{ name: "medical-report.pdf" }],
        tags: ["food", "mess"],
        victims: [{ name: "Priya Sharma", reg: "22BTBIO077" }],
        witnesses: [{ name: "Mess Supervisor", contact: "+91 9XXXXXX911" }],
        accused: [],
        assignedTo: "Health & Food Safety",
        adminNotes: "",
    },

    {
        id: "CMP-MH-E-412-20251014-0830-02",
        title: "Internet not working",
        cat: "Maintenance",
        priority: "Low",
        status: "Pending",
        updated: "14 Oct, 08:40",
        reporterType: "student",
        reporter: "Karthik S",
        regno: "22IT0703",
        reporterDept: "IT",
        reporterContact: "+91 9XXXXXX482",
        hostelType: "MH",
        hostelBlock: "E",
        roomNumber: "412",
        submittedAt: "14 Oct, 08:30",
        location: "MH E-Block 4th Floor",
        subcategory: "network",
        incidentDateTime: "2025-10-14 08:15",
        titleSubmitted: "Wi-Fi down",
        summary: "Wi-Fi not connecting since morning.",
        details:
        "Other rooms also facing same issue. Router reboot requested.",
        attachments: [],
        tags: ["wifi", "network"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Network Team",
        adminNotes: "",
    },

    {
        id: "CMP-LH-D-005-20251012-2300-01",
        title: "Water leakage in bathroom",
        cat: "Maintenance",
        priority: "High",
        status: "Resolved",
        updated: "12 Oct, 23:30",
        reporterType: "student",
        reporter: "Ananya Singh",
        regno: "22ECE0678",
        reporterDept: "ECE",
        reporterContact: "+91 9XXXXXX789",
        hostelType: "LH",
        hostelBlock: "D",
        roomNumber: "005",
        submittedAt: "12 Oct, 23:00",
        location: "LH D-005",
        subcategory: "plumbing",
        incidentDateTime: "2025-10-12 22:50",
        titleSubmitted: "Water leakage in bathroom",
        summary: "Continuous water leak from ceiling pipe.",
        details: "Plumber attended. Pipe replaced successfully.",
        attachments: [{ name: "repair-photo.jpg" }],
        tags: ["maintenance", "water"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Plumbing Dept",
        adminNotes: "Resolved within 2 hours.",
    },

    {
        id: "CMP-ACD-203-20251015-1415-01",
        title: "Unfair grading concern",
        cat: "Academics",
        priority: "Medium",
        status: "In Review",
        updated: "15 Oct, 14:30",
        reporterType: "student",
        reporter: "Vikram Patel",
        regno: "22MEC0442",
        reporterDept: "Mechanical",
        reporterContact: "+91 9XXXXXX223",
        location: "Academic Block 3",
        submittedAt: "15 Oct, 14:15",
        subcategory: "grading",
        incidentDateTime: "2025-10-15 14:00",
        titleSubmitted: "Unfair grading concern",
        summary: "Assignment marks deducted unfairly.",
        details:
        "Submitted on time, but marks reduced due to formatting issue.",
        attachments: [{ name: "assignment.pdf" }],
        tags: ["academics", "grading"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Course Instructor",
        adminNotes: "",
    },

    {
        id: "CMP-MH-F-311-20251013-2205-02",
        title: "Unauthorized entry at night",
        cat: "Safety",
        priority: "Emergency",
        status: "In Progress",
        updated: "13 Oct, 22:15",
        reporterType: "faculty",
        facultyId: "VIT56789",
        facultyName: "Prof. Nitin Rao",
        facultyDept: "Security",
        facultyDesignation: "Chief Warden",
        facultyContact: "+91 9XXXXXX951",
        reporter: "Security Staff",
        regno: "",
        location: "MH F-311",
        submittedAt: "13 Oct, 22:05",
        subcategory: "intrusion",
        incidentDateTime: "2025-10-13 21:55",
        titleSubmitted: "Unauthorized entry at night",
        summary:
        "Unknown person entered MH F-Block after curfew.",
        details:
        "Security camera shows male student from another block entering.",
        attachments: [{ name: "cctv-footage.mp4" }],
        tags: ["safety", "intrusion"],
        victims: [],
        witnesses: [{ name: "Security Staff" }],
        accused: [{ name: "Unknown male", role: "student" }],
        assignedTo: "Security Team",
        adminNotes: "",
    },

    {
        id: "CMP-LH-MESS-20251012-1230-02",
        title: "Insect found in food",
        cat: "Food",
        priority: "High",
        status: "Resolved",
        updated: "12 Oct, 14:00",
        reporterType: "student",
        reporter: "Divya Iyer",
        regno: "22CSE0567",
        reporterDept: "CSE",
        reporterContact: "+91 9XXXXXX444",
        location: "LH Mess",
        submittedAt: "12 Oct, 12:30",
        subcategory: "food_hygiene",
        incidentDateTime: "2025-10-12 12:15",
        titleSubmitted: "Insect found in lunch curry",
        summary: "Found an insect in food served during lunch.",
        details:
        "Reported to mess supervisor, kitchen inspected and sanitized.",
        attachments: [{ name: "photo-evidence.jpg" }],
        tags: ["food", "mess"],
        victims: [],
        witnesses: [{ name: "Mess Incharge" }],
        accused: [],
        assignedTo: "Mess Committee",
        adminNotes: "Mess cleaned, complaint resolved.",
    },

    {
        id: "CMP-MH-A-001-20251011-0930-01",
        title: "Noise disturbance early morning",
        cat: "Safety",
        priority: "Low",
        status: "Pending",
        updated: "11 Oct, 09:40",
        reporterType: "student",
        reporter: "Aditya Jain",
        regno: "22EEE0412",
        reporterDept: "EEE",
        reporterContact: "+91 9XXXXXX911",
        hostelType: "MH",
        hostelBlock: "A",
        roomNumber: "001",
        submittedAt: "11 Oct, 09:30",
        location: "MH A-001",
        subcategory: "disturbance",
        incidentDateTime: "2025-10-11 09:10",
        titleSubmitted: "Noise disturbance early morning",
        summary: "Loud music from nearby room.",
        details:
        "Requested warden intervention to ensure quiet hours maintained.",
        attachments: [],
        tags: ["noise"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Warden Office",
        adminNotes: "",
    },

    {
        id: "CMP-SPORTS-20251013-1630-01",
        title: "Injury during football match",
        cat: "Safety",
        priority: "High",
        status: "Resolved",
        updated: "13 Oct, 16:40",
        reporterType: "faculty",
        facultyId: "VIT33322",
        facultyName: "Dr. Sneha Pillai",
        facultyDept: "Physical Education",
        facultyDesignation: "Sports Coordinator",
        facultyContact: "+91 9XXXXXX761",
        reporter: "Rahul R",
        regno: "22MEC0666",
        location: "Football Ground",
        submittedAt: "13 Oct, 16:30",
        subcategory: "injury",
        incidentDateTime: "2025-10-13 16:15",
        titleSubmitted: "Injury during football match",
        summary: "Player injured during inter-house match.",
        details:
        "Medical team responded immediately. Minor sprain confirmed.",
        attachments: [{ name: "med-clearance.pdf" }],
        tags: ["sports", "safety"],
        victims: [{ name: "Rahul R", reg: "22MEC0666" }],
        witnesses: [{ name: "Team Captain" }],
        accused: [],
        assignedTo: "Health Center",
        adminNotes: "No further action required.",
    },

    {
        id: "CMP-LIB-20251010-1100-01",
        title: "AC not working in reading room",
        cat: "Maintenance",
        priority: "Medium",
        status: "In Review",
        updated: "10 Oct, 11:30",
        reporterType: "faculty",
        facultyId: "VIT44566",
        facultyName: "Dr. Ramesh Krishnan",
        facultyDept: "Library Services",
        facultyDesignation: "Librarian",
        facultyContact: "+91 9XXXXXX555",
        location: "Central Library",
        submittedAt: "10 Oct, 11:00",
        subcategory: "ac_unit",
        incidentDateTime: "2025-10-10 10:45",
        titleSubmitted: "AC not cooling properly",
        summary: "AC not cooling even after restart.",
        details:
        "Requested technical team to inspect. Students uncomfortable in hall.",
        attachments: [],
        tags: ["maintenance", "AC"],
        victims: [],
        witnesses: [],
        accused: [],
        assignedTo: "Maintenance Dept",
        adminNotes: "",
    },
    ];

    /** Tabs & constants */
    const TAB_LIST = ["All", "Pending", "In Review", "In Progress", "Resolved", "Rejected", "Emergency"];
    const STATUSES = ["Submitted", "Pending", "In Review", "In Progress", "Resolved", "Rejected"];
    const PRIORITIES = ["Low", "Medium", "High", "Emergency"];
    const CATEGORIES = ["Safety", "Maintenance", "Food", "Academics", "Other"];

    /* ---------------- Local log helpers (frontend-only) ---------------- */
    const LOG_KEY = "wdcmLogs";
    const readLogs = (id) => {
    try {
        const all = JSON.parse(localStorage.getItem(LOG_KEY) || "{}");
        return all[id] || [];
    } catch {
        return [];
    }
    };
    const writeLogs = (id, next) => {
    try {
        const all = JSON.parse(localStorage.getItem(LOG_KEY) || "{}");
        all[id] = next;
        localStorage.setItem(LOG_KEY, JSON.stringify(all));
    } catch {}
    };
    const pushLog = (id, entry) => {
    const now = new Date();
    const payload = {
        ts: now.toISOString(),
        when: now.toLocaleString(),
        ...entry, // {who, action, note, meta}
    };
    const cur = readLogs(id);
    const next = [payload, ...cur];
    writeLogs(id, next);
    return next;
    };

    /** ---------------- STRICT SCOPE HELPERS ---------------- */
    const U = (s) => String(s ?? "").trim().toUpperCase();

    /** Builds a set of exact pairs like "MH-A" from new wardenScope prop */
    const buildAllowedFromScope = (wardenScope) => {
    const h = (wardenScope?.hostelTypes || []).map(U).filter(Boolean);
    const b = (wardenScope?.blocks || []).map(U).filter(Boolean);
    const set = new Set();
    for (const ht of h) {
        for (const bl of b) {
        set.add(`${ht}-${bl}`);
        }
    }
    return set;
    };

    /** Back-compat: also support allowedBlocks=["MH-A","LH-C"] */
    const buildAllowedFromList = (allowedBlocks) => {
    const set = new Set();
    (allowedBlocks || []).forEach((s) => {
        const v = U(s);
        if (v.includes("-")) set.add(v);
    });
    return set;
    };

    const keyForItem = (x) => {
    const h = U(x?.hostelType);
    const b = U(x?.hostelBlock);
    return h && b ? `${h}-${b}` : null;
    };

    const itemAllowed = (x, allowedSet, scopeActive) => {
    if (!scopeActive) return true; // if no scope specified, show everything (demo fallback)
    const k = keyForItem(x);
    if (!k) return false;          // hide items without hostelType/hostelBlock when scoped
    return allowedSet.has(k);
    };

    export  function WardenComplaintManager({
    data = [],
    /** Back-compat: exact pairs like ["MH-A","LH-C"] */
    allowedBlocks = undefined,
    /** Preferred: strict pairing via hostelTypes + blocks, e.g. {hostelTypes:["MH"], blocks:["A"]} */
    wardenScope = undefined,
    }) {
    // Build the allowed set (scope) — prefer wardenScope; else allowedBlocks; else no scope
    const allowedSet = useMemo(() => {
        const fromScope = buildAllowedFromScope(wardenScope);
        if (fromScope.size) return fromScope;
        const fromList = buildAllowedFromList(allowedBlocks);
        if (fromList.size) return fromList;
        return new Set(); // empty set means "no scope" (show all for demo)
    }, [wardenScope, allowedBlocks]);

    const scopeActive = allowedSet.size > 0;

    // Initial items: filter strictly by exact MH/LH + Block pair if scope active
    const initialItems = useMemo(() => {
        const src = data.length ? data : seed;
        return src.filter((x) => itemAllowed(x, allowedSet, scopeActive));
    }, [data, allowedSet, scopeActive]);

    const [items, setItems] = useState(initialItems);
    useEffect(() => setItems(initialItems), [initialItems]);

    // list header state
    const [active, setActive] = useState("All");
    const [sort, setSort] = useState("recent");
    const [q, setQ] = useState("");
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);

    // modal & selection
    const [open, setOpen] = useState(false);
    const [selected, setSelected] = useState(null);

    // log drawer
    const [logOpen, setLogOpen] = useState(false);
    const [logs, setLogs] = useState([]);

    // refs for focus management
    const logBtnRef = useRef(null);
    const logCloseBtnRef = useRef(null);

    // counts for tab badges
    const counts = useMemo(() => {
        const base = {
        All: items.length,
        Pending: 0,
        "In Review": 0,
        "In Progress": 0,
        Resolved: 0,
        Rejected: 0,
        Emergency: 0,
        };
        for (const it of items) {
        if (base[it.status] !== undefined) base[it.status] += 1;
        if (it.priority === "Emergency") base.Emergency += 1;
        }
        return base;
    }, [items]);

    // filter/sort/search
    const filtered = useMemo(() => {
        let list = [...items];
        if (active === "Emergency") list = list.filter((x) => x.priority === "Emergency");
        else if (active !== "All") list = list.filter((x) => x.status === active);

        if (q.trim()) {
        const t = q.toLowerCase();
        list = list.filter(
            (x) =>
            x.id.toLowerCase().includes(t) ||
            x.title.toLowerCase().includes(t) ||
            (x.reporter || "").toLowerCase().includes(t) ||
            (x.regno || "").toLowerCase().includes(t)
        );
        }

        if (sort === "priority") {
        const rank = { Emergency: 3, High: 2, Medium: 1, Low: 0 };
        list.sort((a, b) => (rank[b.priority] ?? 0) - (rank[a.priority] ?? 0));
        } else if (sort === "category") {
        list.sort((a, b) => a.cat.localeCompare(b.cat));
        }
        return list;
    }, [items, active, sort, q]);

    // paging slice
    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const pageSafe = Math.min(page, totalPages);
    const start = (pageSafe - 1) * pageSize;
    const visible = filtered.slice(start, start + pageSize);

    // open/close helpers
    const openPanel = (it) => {
        setSelected({ ...it, adminNotes: it.adminNotes || "", tagInput: "" });
        setLogs(readLogs(it.id));
        setOpen(true);
        setLogOpen(false);
    };
    const mutate = (k, v) =>
        setSelected((s) => ({ ...s, [k]: typeof v === "function" ? v(s[k]) : v }));

    // record diffs on save (frontend-only log)
    const save = () => {
        const before = items.find((x) => x.id === selected.id) || {};
        const changes = [];
        [
        ["status", "Status"],
        ["priority", "Priority"],
        ["cat", "Category"],
        ["assignedTo", "Assigned To"],
        ].forEach(([key, label]) => {
        if (before[key] !== selected[key]) {
            changes.push(`${label}: “${before[key] ?? "—"}” → “${selected[key]}”`);
        }
        });

        if (changes.length) {
        const entry = { who: "Warden", action: "Edited case", note: changes.join("; ") };
        const next = pushLog(selected.id, entry);
        setLogs(next);
        }

        setItems((prev) =>
        prev.map((x) =>
            x.id === selected.id ? { ...selected, updated: "Just now" } : x
        )
        );
        setOpen(false);
    };

    const actionAndLog = (newStatus, actionLabel) => {
        mutate("status", newStatus);
        const next = pushLog(selected.id, {
        who: "Warden",
        action: actionLabel,
        note: `Status set to “${newStatus}”`,
        });
        setLogs(next);
    };

    // Esc to close modal
    useEffect(() => {
        if (!open) return;
        const onKey = (e) => e.key === "Escape" && setOpen(false);
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, [open]);

    // Drawer: keep logs fresh when opened; ESC closes; focus management
    useEffect(() => {
        if (!selected) return;
        if (logOpen) {
        setLogs(readLogs(selected.id));
        const onKey = (e) => {
            if (e.key === "Escape") {
            setLogOpen(false);
            setTimeout(() => logBtnRef.current?.focus(), 0);
            }
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
        }
    }, [logOpen, selected]);

    // tags
    const addTag = () => {
        const t = (selected.tagInput || "").trim();
        if (!t) return;
        if ((selected.tags || []).includes(t)) return mutate("tagInput", "");
        mutate("tags", [...(selected.tags || []), t]);
        mutate("tagInput", "");
        const next = pushLog(selected.id, {
        who: "Warden",
        action: "Added tag",
        meta: { tag: t },
        note: `+ ${t}`,
        });
        setLogs(next);
    };
    const removeTag = (t) => {
        mutate("tags", (selected.tags || []).filter((x) => x !== t));
        const next = pushLog(selected.id, {
        who: "Warden",
        action: "Removed tag",
        meta: { tag: t },
        note: `– ${t}`,
        });
        setLogs(next);
    };

    return (
        <WardenLayout>
        {/* ------- LIST PAGE ------- */}
        <div className="wdcm-page">
            <header className="wdcm-header">
            <div>
                <h1 className="wdcm-title">Complaint Dashboard</h1>
                <p className="wdcm-sub">
                Warden view – manage, update, and resolve complaints (your blocks only).
                </p>
            </div>
            <div className="wdcm-actions">
                <input
                className="wdcm-search"
                value={q}
                onChange={(e) => {
                    setQ(e.target.value);
                    setPage(1);
                }}
                placeholder="Search by ID, title, or reg. no."
                />
                <select
                className="wdcm-sort"
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                >
                <option value="recent">Recent first</option>
                <option value="priority">By priority</option>
                <option value="category">By category</option>
                </select>
                <select
                className="wdcm-sort"
                value={pageSize}
                onChange={(e) => {
                    setPageSize(parseInt(e.target.value, 10));
                    setPage(1);
                }}
                >
                <option value={5}>5 / page</option>
                <option value={10}>10 / page</option>
                <option value={20}>20 / page</option>
                <option value={50}>50 / page</option>
                <option value={100}>100 / page</option>
                </select>
            </div>
            </header>

            <div className="wdcm-tabs">
            {TAB_LIST.map((t) => (
                <button
                key={t}
                className={`wdcm-tab ${active === t ? "active" : ""}`}
                onClick={() => {
                    setActive(t);
                    setPage(1);
                }}
                type="button"
                >
                <span>{t}</span>
                <span className="wdcm-badge">{counts[t] ?? 0}</span>
                {active === t && <i className="wdcm-underline" />}
                </button>
            ))}
            </div>

            <div className="wdcm-list">
            {visible.map((c) => (
                <article
                key={c.id}
                className={`wdcm-card ${c.priority.toLowerCase()} ${
                    c.status === "Resolved" ? "is-ok" : ""
                }`}
                onClick={() => openPanel(c)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === "Enter" && openPanel(c)}
                >
                <div className="wdcm-rail" />
                <div className="wdcm-card-left">
                    <h3 className="wdcm-card-title">{c.title}</h3>
                    <p className="wdcm-id">{c.id}</p>
                    <div className="wdcm-meta-line">
                    <span>{c.reporter}</span>
                    <span>•</span>
                    <span>{c.regno}</span>
                    <span>•</span>
                    <span>{c.location}</span>
                    </div>
                </div>
                <div className="wdcm-card-right" onClick={(e) => e.stopPropagation()}>
                    <span className="wdcm-chip tone-cat">{c.cat}</span>
                    <span className={`wdcm-chip tone-${c.priority.toLowerCase()}`}>{c.priority}</span>
                    <span className="wdcm-chip tone-status">{c.status}</span>
                    <span className="wdcm-time">Updated: {c.updated}</span>
                </div>
                </article>
            ))}
            {!visible.length && (
                <div className="wdcm-empty" style={{ marginTop: 12 }}>
                {total === 0 ? "No complaints found." : "No results on this page."}
                </div>
            )}
            </div>

            {Math.ceil(total / pageSize) > 1 && (
            <div className="wdcm-pager">
                <button
                className="wdcm-page-btn"
                disabled={pageSafe <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                type="button"
                >
                ← Prev
                </button>
                <div className="wdcm-page-indicator">
                Page {pageSafe} / {Math.ceil(total / pageSize)}
                </div>
                <button
                className="wdcm-page-btn"
                disabled={pageSafe >= Math.ceil(total / pageSize)}
                onClick={() => setPage((p) => p + 1)}
                type="button"
                >
                Next →
                </button>
            </div>
            )}
        </div>

        {/* ------- CASE PANEL ------- */}
        {open && selected && (
            <div className="wdcm-modal show" onClick={() => setOpen(false)}>
            <div className="wdcm-panel" onClick={(e) => e.stopPropagation()}>
                {/* Header */}
                <div className="wdcm-panel-head" role="banner">
                <div className="wdcm-titleblock">
                    <h2 id="wdcm-panel-title">{selected.title}</h2>
                    <p className="wdcm-subid">{selected.id}</p>
                </div>
                <div className="wdcm-head-actions">
                    <button
                    ref={logBtnRef}
                    type="button"
                    className="wdcm-btn ghost wdcm-log-btn"
                    onClick={() => {
                        setLogs(readLogs(selected.id)); // refresh logs each time we open
                        setLogOpen((v) => !v);
                        setTimeout(() => logCloseBtnRef.current?.focus(), 50);
                    }}
                    title="View case log"
                    aria-expanded={logOpen}
                    aria-controls="wdcm-log-drawer"
                    >
                    View Log
                    </button>
                    <br />
                    <button
                    className="wdcm-close"
                    aria-label="Close"
                    onClick={() => setOpen(false)}
                    type="button"
                    >
                    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                        <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                    </button>
                </div>
                </div>

                {/* Scrollable Body */}
                <div className="wdcm-panel-body">
                {/* Reporter snapshot (READ-ONLY) */}
                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Reporter</h4>

                    {selected.reporterType === "student" && (
                    <>
                        <div className="wdcm-ro-grid">
                        <div>
                            <label>Name</label>
                            <div className="wdcm-ro">{selected.reporter || "—"}</div>
                        </div>
                        <div>
                            <label>Reg / ID</label>
                            <div className="wdcm-ro">{selected.regno || "—"}</div>
                        </div>
                        <div>
                            <label>Department</label>
                            <div className="wdcm-ro">{selected.reporterDept || "—"}</div>
                        </div>
                        <div>
                            <label>Contact</label>
                            <div className="wdcm-ro">{selected.reporterContact || "—"}</div>
                        </div>
                        <div>
                            <label>Submitted</label>
                            <div className="wdcm-ro">{selected.submittedAt || "—"}</div>
                        </div>
                        </div>

                        <div className="wdcm-ro-grid">
                        <div>
                            <label>Hostel Type</label>
                            <div className="wdcm-ro">{selected.hostelType || "—"}</div>
                        </div>
                        <div>
                            <label>Block</label>
                            <div className="wdcm-ro">{selected.hostelBlock || "—"}</div>
                        </div>
                        <div>
                            <label>Room</label>
                            <div className="wdcm-ro">{selected.roomNumber || "—"}</div>
                        </div>
                        </div>
                    </>
                    )}

                    {selected.reporterType === "faculty" && (
                    <>
                        <div className="wdcm-ro-grid">
                        <div>
                            <label>Faculty ID</label>
                            <div className="wdcm-ro">{selected.facultyId || "—"}</div>
                        </div>
                        <div>
                            <label>Name</label>
                            <div className="wdcm-ro">{selected.facultyName || "—"}</div>
                        </div>
                        <div>
                            <label>Department</label>
                            <div className="wdcm-ro">{selected.facultyDept || "—"}</div>
                        </div>
                        <div>
                            <label>Designation</label>
                            <div className="wdcm-ro">{selected.facultyDesignation || "—"}</div>
                        </div>
                        <div>
                            <label>Contact</label>
                            <div className="wdcm-ro">{selected.facultyContact || "—"}</div>
                        </div>
                        <div>
                            <label>Submitted</label>
                            <div className="wdcm-ro">{selected.submittedAt || "—"}</div>
                        </div>
                        </div>
                        {(selected.reporter || selected.regno) && (
                        <div className="wdcm-note">
                            Filed about student: <b>{selected.reporter || "—"}</b> ({selected.regno || "—"})
                        </div>
                        )}
                    </>
                    )}
                </section>

                {/* Incident (READ-ONLY) */}
                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Incident Details</h4>
                    <div className="wdcm-ro-grid">
                    <div>
                        <label>Category</label>
                        <div className="wdcm-ro">{selected.cat || "—"}</div>
                    </div>
                    <div>
                        <label>Subcategory</label>
                        <div className="wdcm-ro">{selected.subcategory || "—"}</div>
                    </div>
                    <div>
                        <label>Priority</label>
                        <div className="wdcm-ro">{selected.priority || "—"}</div>
                    </div>
                    <div>
                        <label>Date & Time</label>
                        <div className="wdcm-ro">{selected.incidentDateTime || "—"}</div>
                    </div>
                    <div className="wdcm-span-2">
                        <label>Location / Place</label>
                        <div className="wdcm-ro">{selected.location || "—"}</div>
                    </div>
                    </div>
                    <div className="wdcm-ro-grid">
                    <div className="wdcm-span-2">
                        <label>Title / Subject</label>
                        <div className="wdcm-ro">{selected.titleSubmitted || selected.title || "—"}</div>
                    </div>
                    </div>
                    <label className="wdcm-lab">
                    Summary
                    <div className="wdcm-roarea">{selected.summary || "—"}</div>
                    </label>
                    <label className="wdcm-lab">
                    Detailed Description
                    <div className="wdcm-roarea">{selected.details || "—"}</div>
                    </label>
                </section>

                {/* People blocks (READ-ONLY) */}
                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Victims</h4>
                    {selected.victims?.length ? (
                    <ul className="wdcm-people">
                        {selected.victims.map((v, i) => (
                        <li key={`v-${i}`} className="wdcm-person">
                            <div className="wdcm-person-line">
                            <b>{v.name || "—"}</b>
                            {v.reg ? <span className="wdcm-tag">{v.reg}</span> : null}
                            {v.contact ? <span className="wdcm-tag">{v.contact}</span> : null}
                            </div>
                            {v.description ? <div className="wdcm-person-note">{v.description}</div> : null}
                        </li>
                        ))}
                    </ul>
                    ) : (
                    <div className="wdcm-muted">No victims recorded.</div>
                    )}
                </section>

                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Accused (if identified)</h4>
                    {selected.accused?.length ? (
                    <ul className="wdcm-people">
                        {selected.accused.map((a, i) => (
                        <li key={`a-${i}`} className="wdcm-person">
                            <div className="wdcm-person-line">
                            <b>{a.name || "—"}</b>
                            {a.role ? <span className="wdcm-tag">{String(a.role).toUpperCase()}</span> : null}
                            {a.id ? <span className="wdcm-tag">{a.id}</span> : null}
                            {a.contact ? <span className="wdcm-tag">{a.contact}</span> : null}
                            </div>
                            {a.description ? <div className="wdcm-person-note">{a.description}</div> : null}
                        </li>
                        ))}
                    </ul>
                    ) : (
                    <div className="wdcm-muted">No accused identified in report.</div>
                    )}
                </section>

                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Witnesses</h4>
                    {selected.witnesses?.length ? (
                    <ul className="wdcm-people">
                        {selected.witnesses.map((w, i) => (
                        <li key={`w-${i}`} className="wdcm-person">
                            <div className="wdcm-person-line">
                            <b>{w.name || "—"}</b>
                            {(w.regNo || w.reg) ? <span className="wdcm-tag">{w.regNo || w.reg}</span> : null}
                            {w.contact ? <span className="wdcm-tag">{w.contact}</span> : null}
                            </div>
                            {w.description ? <div className="wdcm-person-note">{w.description}</div> : null}
                        </li>
                        ))}
                    </ul>
                    ) : (
                    <div className="wdcm-muted">No witnesses recorded.</div>
                    )}
                </section>

                {/* Tags + Attachments */}
                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Tags & Attachments</h4>

                    <div className="wdcm-tag-editor">
                    <div className="wdcm-chips">
                        {(selected.tags || []).map((t) => (
                        <span key={t} className="wdcm-chip-pill">
                            {t}
                            <button
                            className="wdcm-x"
                            onClick={() => removeTag(t)}
                            aria-label={`Remove ${t}`}
                            type="button"
                            >
                            ×
                            </button>
                        </span>
                        ))}
                        {!selected.tags?.length && <span className="wdcm-muted">No tags</span>}
                    </div>

                    <div className="wdcm-addtag">
                        <input
                        placeholder="Add tag…"
                        value={selected.tagInput || ""}
                        onChange={(e) => mutate("tagInput", e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                        />
                        <button type="button" className="wdcm-btn ghost" onClick={addTag}>
                        Add
                        </button>
                    </div>
                    </div>

                    <div className="wdcm-attachments">
                    {Array.isArray(selected.attachments) && selected.attachments.length ? (
                        <div className="wdcm-files">
                        {selected.attachments.map((f, i) => (
                            <span key={i} className="wdcm-file">
                            {typeof f === "string" ? f : f.name}
                            </span>
                        ))}
                        </div>
                    ) : (
                        <span className="wdcm-chip tone-status">No attachments</span>
                    )}
                    <button className="wdcm-btn ghost" type="button">
                        View
                    </button>
                    <button className="wdcm-btn ghost" type="button">
                        Add
                    </button>
                    </div>
                </section>

                {/* Case controls */}
                <section className="wdcm-sec">
                    <h4 className="wdcm-sec-title">Case Controls</h4>
                    <div className="wdcm-edit-grid">
                    <label>
                        Status
                        <select value={selected.status} onChange={(e) => mutate("status", e.target.value)}>
                        {STATUSES.map((s) => (
                            <option key={s}>{s}</option>
                        ))}
                        </select>
                    </label>
                    <label>
                        Priority
                        <select value={selected.priority} onChange={(e) => mutate("priority", e.target.value)}>
                        {PRIORITIES.map((p) => (
                            <option key={p}>{p}</option>
                        ))}
                        </select>
                    </label>
                    <label>
                        Category
                        <select value={selected.cat} onChange={(e) => mutate("cat", e.target.value)}>
                        {CATEGORIES.map((c) => (
                            <option key={c}>{c}</option>
                        ))}
                        </select>
                    </label>
                    <label>
                        Assigned To
                        <input value={selected.assignedTo || ""} onChange={(e) => mutate("assignedTo", e.target.value)} />
                    </label>
                    </div>
                </section>
                </div>

                {/* Sticky footer actions */}
                <div className="wdcm-actions-bar">
                <textarea
                    className="wdcm-notes"
                    rows={2}
                    placeholder="Internal notes / decision log…"
                    value={selected.adminNotes || ""}
                    onChange={(e) => mutate("adminNotes", e.target.value)}
                />
                <div className="wdcm-actions-row">
                    <button className="save" onClick={save} type="button">
                    Save
                    </button>
                    <button
                    className="warn"
                    onClick={() => actionAndLog("In Progress", "Escalated")}
                    type="button"
                    >
                    Escalate
                    </button>
                    <button
                    className="ok"
                    onClick={() => actionAndLog("Resolved", "Resolved")}
                    type="button"
                    >
                    Resolve
                    </button>
                    <button
                    className="danger"
                    onClick={() => actionAndLog("Rejected", "Rejected")}
                    type="button"
                    >
                    Reject
                    </button>
                </div>
                </div>

                {/* --------- View Log Drawer (always mounted) ---------- */}
                <aside
                id="wdcm-log-drawer"
                className={`wdcm-log-drawer ${logOpen ? "show" : ""}`}
                role="complementary"
                aria-label="Case Log"
                aria-hidden={!logOpen}
                onClick={(e) => e.stopPropagation()}
                >
                <div className="wdcm-log-head">
                    <h4 style={{ margin: 0 }}>Case Log</h4>
                    <span className="wdcm-log-count">{logs.length} entries</span>
                    <button
                    ref={logCloseBtnRef}
                    className="wdcm-xbtn"
                    onClick={() => {
                        setLogOpen(false);
                        setTimeout(() => logBtnRef.current?.focus(), 0);
                    }}
                    type="button"
                    aria-label="Close log"
                    title="Close"
                    >
                    ×
                    </button>
                </div>

                <div className="wdcm-log-body">
                    {!logs.length ? (
                    <div className="wdcm-log-empty">No activity yet.</div>
                    ) : (
                    <ul className="wdcm-timeline">
                        {logs.map((lg, i) => {
                        const type =
                            lg.action === "Resolved"
                            ? "Resolved"
                            : lg.action === "Rejected"
                            ? "Rejected"
                            : lg.action === "Escalated"
                            ? "Escalated"
                            : "Edited";
                        return (
                            <li key={i} className={`wdcm-tl-item ${type}`}>
                            <span className="wdcm-tl-dot" />
                            <div className="wdcm-tl-card">
                                <div className="wdcm-tl-top">
                                <span className="wdcm-tl-action">{lg.action}</span>
                                <span className="wdcm-tl-time">{lg.when}</span>
                                </div>
                                {lg.note && <div className="wdcm-tl-note">{lg.note}</div>}
                                <div className="wdcm-tl-meta">{lg.who ? `by ${lg.who}` : "—"}</div>
                            </div>
                            </li>
                        );
                        })}
                    </ul>
                    )}
                </div>
                </aside>
                {/* --------- /View Log Drawer ---------- */}
            </div>
            </div>
        )}
        
        </WardenLayout>
    );
}
        export default function WardenCMPage() {
  return (
    <WardenComplaintManager wardenScope={{ hostelTypes: ["MH"], blocks: ["A"] }} />
  );
}
    


