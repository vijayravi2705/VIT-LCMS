import React, { useEffect, useMemo, useState, useRef } from "react";
import "../assets/styles/wardenprofile.css"; // <-- new stylesheet
import WardenLayout from "../layouts/WardenLayout";

const DEFAULT = {
  id: "WRD-2025-02",
  name: "Mr. Aditya Sen",
  dept: "Hostel Administration",
  email: "aditya@univ.edu",
  phone: "+91 90000 00002",
  office: "Hostel Office, Ground Floor",
  blocks: ["LH-C"],
  avatar: "", // optional URL or data-URL; falls back to initials
};

export default function WardenProfile() {
  const [data, setData] = useState(DEFAULT);
  const [draft, setDraft] = useState(DEFAULT);
  const [edit, setEdit] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    const raw = localStorage.getItem("warden:profile");
    if (raw) {
      const parsed = JSON.parse(raw);
      setData(parsed);
      setDraft(parsed);
    }
  }, []);

  const initials = useMemo(
    () =>
      (data.name || "")
        .split(" ")
        .map((x) => x[0])
        .slice(0, 2)
        .join("")
        .toUpperCase(),
    [data.name]
  );

  const save = () => {
    const cleaned = {
      ...draft,
      name: (draft.name || "").trim(),
      dept: (draft.dept || "").trim(),
      email: (draft.email || "").trim(),
      phone: (draft.phone || "").trim(),
      office: (draft.office || "").trim(),
      avatar: (draft.avatar || "").trim(),
      blocks: Array.from(
        new Set((draft.blocks || []).map((b) => b.trim().toUpperCase()))
      ).filter(Boolean),
    };
    setData(cleaned);
    localStorage.setItem("warden:profile", JSON.stringify(cleaned));
    setEdit(false);
  };

  const cancel = () => {
    setDraft(data);
    setEdit(false);
  };

  const onAvatarFile = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const url = String(ev.target?.result || "");
      setDraft((d) => ({ ...d, avatar: url }));
    };
    reader.readAsDataURL(f);
  };

  return (
    <WardenLayout>
      <div className="wdp-wrap">
        {/* Header */}
        <header className="wdp-head">
          <div className="wdp-head-left">
            <div className="wdp-avatar">
              {data.avatar ? (
                <img src={edit ? (draft.avatar || data.avatar) : data.avatar} alt={data.name} />
              ) : (
                <div className="wdp-avatar-badge">{initials}</div>
              )}

              {edit && (
                <label className="wdp-upload-btn" title="Upload avatar">
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    onChange={onAvatarFile}
                  />
                  ⬆
                </label>
              )}
            </div>

            <div className="wdp-title-block">
              <h1 className="wdp-name">{edit ? (draft.name || "—") : data.name}</h1>
              <p className="wdp-title">Warden • {edit ? (draft.dept || "—") : data.dept}</p>
              <div className="wdp-meta">
                <span className="wdp-meta-chip">{edit ? (draft.email || "—") : data.email}</span>
                <span className="wdp-meta-chip">{edit ? (draft.phone || "—") : data.phone}</span>
                <span className="wdp-meta-chip">{edit ? (draft.office || "—") : data.office}</span>
              </div>
            </div>
          </div>

          <div className="wdp-actions">
            {!edit ? (
              <button className="btn soft" onClick={() => { setDraft(data); setEdit(true); }}>
                Edit
              </button>
            ) : (
              <>
                <button className="btn ghost" onClick={cancel}>Cancel</button>
                <button className="btn primary" onClick={save}>Save</button>
              </>
            )}
          </div>
        </header>

        {/* Quick KPIs (optional visuals) */}
        <section className="wdp-kpi-grid">
          <div className="wdp-kpi tone--ok">
            <div className="wdp-kpi-top">
              <div className="wdp-kpi-icon">🏠</div>
              <div className="wdp-kpi-label">Assigned Blocks</div>
            </div>
            <div className="wdp-kpi-value">{(edit ? draft : data).blocks.length}</div>
          </div>
          <div className="wdp-kpi">
            <div className="wdp-kpi-top">
              <div className="wdp-kpi-icon">🧑‍💼</div>
              <div className="wdp-kpi-label">Warden ID</div>
            </div>
            <div className="wdp-kpi-value" title={data.id}>{data.id}</div>
          </div>
        </section>

        {/* Editable Fields */}
        <section className="wdp-card">
          <h3 className="wdp-card-title">Basic Details</h3>

          <div className="wdp-form-grid">
            <label className={`wdp-field ${!edit ? "disabled" : ""}`}>
              <span className="wdp-field-label">Name</span>
              <input
                className="wdp-input"
                disabled={!edit}
                value={(edit ? draft : data).name}
                onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
                placeholder="Your full name"
              />
            </label>

            <label className={`wdp-field ${!edit ? "disabled" : ""}`}>
              <span className="wdp-field-label">Department</span>
              <input
                className="wdp-input"
                disabled={!edit}
                value={(edit ? draft : data).dept}
                onChange={(e) => setDraft((d) => ({ ...d, dept: e.target.value }))}
                placeholder="Department"
              />
            </label>

            <label className={`wdp-field ${!edit ? "disabled" : ""}`}>
              <span className="wdp-field-label">Email</span>
              <input
                className="wdp-input"
                disabled={!edit}
                value={(edit ? draft : data).email}
                onChange={(e) => setDraft((d) => ({ ...d, email: e.target.value }))}
                placeholder="name@univ.edu"
              />
            </label>

            <label className={`wdp-field ${!edit ? "disabled" : ""}`}>
              <span className="wdp-field-label">Phone</span>
              <input
                className="wdp-input"
                disabled={!edit}
                value={(edit ? draft : data).phone}
                onChange={(e) => setDraft((d) => ({ ...d, phone: e.target.value }))}
                placeholder="+91 …"
              />
            </label>

            <label className={`wdp-field ${!edit ? "disabled" : ""}`}>
              <span className="wdp-field-label">Office</span>
              <input
                className="wdp-input"
                disabled={!edit}
                value={(edit ? draft : data).office}
                onChange={(e) => setDraft((d) => ({ ...d, office: e.target.value }))}
                placeholder="Office location"
              />
            </label>

            {edit && (
              <label className="wdp-field">
                <span className="wdp-field-label">Avatar URL (optional)</span>
                <input
                  className="wdp-input"
                  value={draft.avatar}
                  onChange={(e) => setDraft((d) => ({ ...d, avatar: e.target.value }))}
                  placeholder="https://…"
                />
                <div className="wdp-hint">You can either paste a URL or use the round upload button on the avatar.</div>
              </label>
            )}
          </div>

        <div className="wdp-tags-block">
  <h4>Assigned Blocks</h4>
  <div className="wdp-tags">
    {data.blocks.map((b, i) => (
      <span key={`${b}-${i}`} className="wdp-tag readonly">
        {b}
      </span>
    ))}
  </div>
  <div className="wdp-hint">These blocks are assigned by the Admin and cannot be changed.</div>
</div>

        </section>
      </div>
    </WardenLayout>
  );
}
