import React, { useMemo, useState, useEffect, useRef } from "react";
import "../assets/styles/WardenComplaint.css";
import WardenLayout from "../layouts/WardenLayout";

/**
 * You can pass data via props too: <WardenComplaintBoard data={...} />
 * By default we reuse your Faculty seed so the UI is identical.
 */
const seed = [
  // — use the exact same hard-coded objects you already pasted for Faculty —
  // (kept here to preserve “same-to-same” demo UX)
  {
      id: "CMP-MH-A-101-20251010-2250-01",
      title: "Ragging incident",
      cat: "Safety",
      priority: "Emergency",
      status: "In Review",
      updated: "10 Oct, 22:58",
      reporterType: "student",
      reporter: "Aarav Menon",
      regno: "22BIT0346",
      reporterDept: "EEE",
      reporterContact: "+91 98XXXXXX12",
      hostelType: "MH",
      hostelBlock: "A",
      roomNumber: "101",
      submittedAt: "10 Oct, 22:50",
      location: "MH A-101",
      subcategory: "ragging",
      incidentDateTime: "2025-10-10 22:40",
      titleSubmitted: "Ragging incident",
      summary: "Verbal abuse reported near hostel A-101.",
      details:
        "Student alleged verbal abuse by seniors. CCTV corridor camera to be checked.",
      attachments: [{ name: "corridor-cam.mp4" }, { name: "statement.pdf" }],
      tags: ["ragging", "safety"],
      victims: [
        {
          name: "Aarav Menon",
          reg: "22BIT0346",
          contact: "+91 98XXXXXX12",
          description: "Verbal abuse by seniors.",
        },
      ],
      witnesses: [{ name: "Block A guard", reg: "", contact: "" }],
      accused: [{ name: "Unknown", role: "student", id: "", contact: "" }],
      assignedTo: "Dean Office",
      adminNotes: "",
    },
    {
      id: "CMP-LH-C-304-20251011-0730-01",
      title: "Suspicious outsider",
      cat: "Safety",
      priority: "High",
      status: "In Progress",
      updated: "11 Oct, 08:10",
      reporterType: "student",
      reporter: "Nisha Varma",
      regno: "22CSE1203",
      reporterDept: "CSE",
      reporterContact: "+91 9XXXXXX321",
      hostelType: "LH",
      hostelBlock: "C",
      roomNumber: "304",
      submittedAt: "11 Oct, 07:30",
      location: "LH C-304",
      subcategory: "suspicious",
      incidentDateTime: "2025-10-11 07:20",
      titleSubmitted: "Suspicious outsider",
      summary: "Unknown person loitering around lecture hall.",
      details:
        "Outsider without ID was seen near C-304. Security alerted to sweep the corridor.",
      attachments: [{ name: "photo.jpg" }],
      tags: ["outsider"],
      victims: [],
      witnesses: [{ name: "Nisha Varma", reg: "22CSE1203", contact: "" }],
      accused: [{ name: "Unknown", role: "outsider", id: "", contact: "" }],
      assignedTo: "Security Team",
      adminNotes: "",
    },
    {
      id: "CMP-MH-B-217-20251012-1905-02",
      title: "Assault reported",
      cat: "Safety",
      priority: "Emergency",
      status: "Submitted",
      updated: "12 Oct, 19:07",
      reporterType: "faculty",
      facultyId: "VIT12345",
      facultyName: "Dr. Jane Doe",
      facultyDept: "EEE",
      facultyDesignation: "Assistant Professor",
      facultyContact: "+91 9XXXXXX987",
      reporter: "Pranav S",
      regno: "22EEE2211",
      location: "MH B-217",
      submittedAt: "12 Oct, 19:05",
      subcategory: "violence",
      incidentDateTime: "2025-10-12 19:00",
      titleSubmitted: "Assault reported",
      summary: "Physical altercation between students.",
      details: "Resident tutor called. Need medical check and statements.",
      attachments: [
        { name: "med-report.png" },
        { name: "rt-note.txt" },
        { name: "cctv-clip.mp4" },
      ],
      tags: [],
      victims: [{ name: "Pranav S", reg: "22EEE2211" }],
      witnesses: [{ name: "RT on duty", reg: "", contact: "" }],
      accused: [{ name: "Unknown", role: "student", id: "", contact: "" }],
      assignedTo: "Warden Office",
      adminNotes: "",
    },
     {
      id: "CMP-MH-D-002-20251012-2100-01",
      title: "Electrical fire smell",
      cat: "Maintenance",
      priority: "High",
      status: "In Review",
      updated: "12 Oct, 21:10",
      reporterType: "student",
      reporter: "Isha Kapoor",
      regno: "22IT0687",
      reporterDept: "IT",
      reporterContact: "+91 9XXXXXX111",
      hostelType: "MH",
      hostelBlock: "D",
      roomNumber: "002",
      submittedAt: "12 Oct, 21:00",
      location: "MH D-002 (panel room)",
      subcategory: "electricity",
      incidentDateTime: "2025-10-12 20:55",
      titleSubmitted: "Electrical fire smell",
      summary: "Burning smell from panel room.",
      details: "Probable overheating of MCB. Immediate shutdown suggested.",
      attachments: [],
      tags: ["electrical", "maintenance"],
      victims: [],
      witnesses: [],
      accused: [],
      assignedTo: "Maintenance",
      adminNotes: "",
    },
    {
    id: "CMP-MH-C-115-20251014-2100-03",
    title: "Broken ceiling fan",
    cat: "Maintenance",
    priority: "Medium",
    status: "In Review",
    updated: "14 Oct, 21:10",
    reporterType: "student",
    reporter: "Rahul Raj",
    regno: "22CSE0421",
    reporterDept: "CSE",
    reporterContact: "+91 9XXXXXX123",
    hostelType: "MH",
    hostelBlock: "C",
    roomNumber: "115",
    submittedAt: "14 Oct, 21:00",
    location: "MH C-115",
    subcategory: "electrical",
    incidentDateTime: "2025-10-14 20:50",
    titleSubmitted: "Broken ceiling fan",
    summary: "Fan stopped working suddenly during night.",
    details: "Fan motor not running even after switch replacement.",
    attachments: [{ name: "fan-issue.jpg" }],
    tags: ["maintenance", "electrical"],
    victims: [],
    witnesses: [],
    accused: [],
    assignedTo: "Maintenance",
    adminNotes: "",
  },

  {
    id: "CMP-LH-B-210-20251013-1900-02",
    title: "Food poisoning after dinner",
    cat: "Food",
    priority: "High",
    status: "In Progress",
    updated: "13 Oct, 19:20",
    reporterType: "student",
    reporter: "Priya Sharma",
    regno: "22BTBIO077",
    reporterDept: "Biotech",
    reporterContact: "+91 9XXXXXX321",
    hostelType: "LH",
    hostelBlock: "B",
    roomNumber: "210",
    submittedAt: "13 Oct, 19:00",
    location: "LH Mess",
    subcategory: "food_quality",
    incidentDateTime: "2025-10-13 18:40",
    titleSubmitted: "Food poisoning after dinner",
    summary: "Several students felt unwell after mess dinner.",
    details: "Likely due to undercooked paneer curry. Medical team informed.",
    attachments: [{ name: "medical-report.pdf" }],
    tags: ["food", "mess"],
    victims: [{ name: "Priya Sharma", reg: "22BTBIO077" }],
    witnesses: [{ name: "Mess Supervisor", contact: "+91 9XXXXXX911" }],
    accused: [],
    assignedTo: "Health & Food Safety",
    adminNotes: "",
  },

  {
    id: "CMP-MH-E-412-20251014-0830-02",
    title: "Internet not working",
    cat: "Maintenance",
    priority: "Low",
    status: "Pending",
    updated: "14 Oct, 08:40",
    reporterType: "student",
    reporter: "Karthik S",
    regno: "22IT0703",
    reporterDept: "IT",
    reporterContact: "+91 9XXXXXX482",
    hostelType: "MH",
    hostelBlock: "E",
    roomNumber: "412",
    submittedAt: "14 Oct, 08:30",
    location: "MH E-Block 4th Floor",
    subcategory: "network",
    incidentDateTime: "2025-10-14 08:15",
    titleSubmitted: "Wi-Fi down",
    summary: "Wi-Fi not connecting since morning.",
    details: "Other rooms also facing same issue. Router reboot requested.",
    attachments: [],
    tags: ["wifi", "network"],
    victims: [],
    witnesses: [],
    accused: [],
    assignedTo: "Network Team",
    adminNotes: "",
  },

  {
    id: "CMP-LH-D-005-20251012-2300-01",
    title: "Water leakage in bathroom",
    cat: "Maintenance",
    priority: "High",
    status: "Resolved",
    updated: "12 Oct, 23:30",
    reporterType: "student",
    reporter: "Ananya Singh",
    regno: "22ECE0678",
    reporterDept: "ECE",
    reporterContact: "+91 9XXXXXX789",
    hostelType: "LH",
    hostelBlock: "D",
    roomNumber: "005",
    submittedAt: "12 Oct, 23:00",
    location: "LH D-005",
    subcategory: "plumbing",
    incidentDateTime: "2025-10-12 22:50",
    titleSubmitted: "Water leakage in bathroom",
    summary: "Continuous water leak from ceiling pipe.",
    details: "Plumber attended. Pipe replaced successfully.",
    attachments: [{ name: "repair-photo.jpg" }],
    tags: ["maintenance", "water"],
    victims: [],
    witnesses: [],
    accused: [],
    assignedTo: "Plumbing Dept",
    adminNotes: "Resolved within 2 hours.",
  },

  {
    id: "CMP-ACD-203-20251015-1415-01",
    title: "Unfair grading concern",
    cat: "Academics",
    priority: "Medium",
    status: "In Review",
    updated: "15 Oct, 14:30",
    reporterType: "student",
    reporter: "Vikram Patel",
    regno: "22MEC0442",
    reporterDept: "Mechanical",
    reporterContact: "+91 9XXXXXX223",
    location: "Academic Block 3",
    submittedAt: "15 Oct, 14:15",
    subcategory: "grading",
    incidentDateTime: "2025-10-15 14:00",
    titleSubmitted: "Unfair grading concern",
    summary: "Assignment marks deducted unfairly.",
    details: "Submitted on time, but marks reduced due to formatting issue.",
    attachments: [{ name: "assignment.pdf" }],
    tags: ["academics", "grading"],
    victims: [],
    witnesses: [],
    accused: [],
    assignedTo: "Course Instructor",
    adminNotes: "",
  },

  {
    id: "CMP-MH-F-311-20251013-2205-02",
    title: "Unauthorized entry at night",
    cat: "Safety",
    priority: "Emergency",
    status: "In Progress",
    updated: "13 Oct, 22:15",
    reporterType: "faculty",
    facultyId: "VIT56789",
    facultyName: "Prof. Nitin Rao",
    facultyDept: "Security",
    facultyDesignation: "Chief Warden",
    facultyContact: "+91 9XXXXXX951",
    reporter: "Security Staff",
    regno: "",
    location: "MH F-311",
    submittedAt: "13 Oct, 22:05",
    subcategory: "intrusion",
    incidentDateTime: "2025-10-13 21:55",
    titleSubmitted: "Unauthorized entry at night",
    summary: "Unknown person entered MH F-Block after curfew.",
    details: "Security camera shows male student from another block entering.",
    attachments: [{ name: "cctv-footage.mp4" }],
    tags: ["safety", "intrusion"],
    victims: [],
    witnesses: [{ name: "Security Staff" }],
    accused: [{ name: "Unknown male", role: "student" }],
    assignedTo: "Security Team",
    adminNotes: "",
  },

  {
    id: "CMP-LH-MESS-20251012-1230-02",
    title: "Insect found in food",
    cat: "Food",
    priority: "High",
    status: "Resolved",
    updated: "12 Oct, 14:00",
    reporterType: "student",
    reporter: "Divya Iyer",
    regno: "22CSE0567",
    reporterDept: "CSE",
    reporterContact: "+91 9XXXXXX444",
    location: "LH Mess",
    submittedAt: "12 Oct, 12:30",
    subcategory: "food_hygiene",
    incidentDateTime: "2025-10-12 12:15",
    titleSubmitted: "Insect found in lunch curry",
    summary: "Found an insect in food served during lunch.",
    details: "Reported to mess supervisor, kitchen inspected and sanitized.",
    attachments: [{ name: "photo-evidence.jpg" }],
    tags: ["food", "mess"],
    victims: [],
    witnesses: [{ name: "Mess Incharge" }],
    accused: [],
    assignedTo: "Mess Committee",
    adminNotes: "Mess cleaned, complaint resolved.",
  },

  {
    id: "CMP-MH-A-001-20251011-0930-01",
    title: "Noise disturbance early morning",
    cat: "Safety",
    priority: "Low",
    status: "Pending",
    updated: "11 Oct, 09:40",
    reporterType: "student",
    reporter: "Aditya Jain",
    regno: "22EEE0412",
    reporterDept: "EEE",
    reporterContact: "+91 9XXXXXX911",
    hostelType: "MH",
    hostelBlock: "A",
    roomNumber: "001",
    submittedAt: "11 Oct, 09:30",
    location: "MH A-001",
    subcategory: "disturbance",
    incidentDateTime: "2025-10-11 09:10",
    titleSubmitted: "Noise disturbance early morning",
    summary: "Loud music from nearby room.",
    details: "Requested warden intervention to ensure quiet hours maintained.",
    attachments: [],
    tags: ["noise"],
    victims: [],
    witnesses: [],
    accused: [],
    assignedTo: "Warden Office",
    adminNotes: "",
  },

  {
    id: "CMP-SPORTS-20251013-1630-01",
    title: "Injury during football match",
    cat: "Safety",
    priority: "High",
    status: "Resolved",
    updated: "13 Oct, 16:40",
    reporterType: "faculty",
    facultyId: "VIT33322",
    facultyName: "Dr. Sneha Pillai",
    facultyDept: "Physical Education",
    facultyDesignation: "Sports Coordinator",
    facultyContact: "+91 9XXXXXX761",
    reporter: "Rahul R",
    regno: "22MEC0666",
    location: "Football Ground",
    submittedAt: "13 Oct, 16:30",
    subcategory: "injury",
    incidentDateTime: "2025-10-13 16:15",
    titleSubmitted: "Injury during football match",
    summary: "Player injured during inter-house match.",
    details: "Medical team responded immediately. Minor sprain confirmed.",
    attachments: [{ name: "med-clearance.pdf" }],
    tags: ["sports", "safety"],
    victims: [{ name: "Rahul R", reg: "22MEC0666" }],
    witnesses: [{ name: "Team Captain" }],
    accused: [],
    assignedTo: "Health Center",
    adminNotes: "No further action required.",
  },

  {
    id: "CMP-LIB-20251010-1100-01",
    title: "AC not working in reading room",
    cat: "Maintenance",
    priority: "Medium",
    status: "In Review",
    updated: "10 Oct, 11:30",
    reporterType: "faculty",
    facultyId: "VIT44566",
    facultyName: "Dr. Ramesh Krishnan",
    facultyDept: "Library Services",
    facultyDesignation: "Librarian",
    facultyContact: "+91 9XXXXXX555",
    location: "Central Library",
    submittedAt: "10 Oct, 11:00",
    subcategory: "ac_unit",
    incidentDateTime: "2025-10-10 10:45",
    titleSubmitted: "AC not cooling properly",
    summary: "AC not cooling even after restart.",
    details: "Requested technical team to inspect. Students uncomfortable in hall.",
    attachments: [],
    tags: ["maintenance", "AC"],
    victims: [],
    witnesses: [],
    accused: [],
    assignedTo: "Maintenance Dept",
    adminNotes: "",
  },
    // ... keep the rest of your seed items exactly as in Faculty ...
];

/* ======= Shared options (kept 1:1) ======= */
const HOSTEL_OPTIONS = {
  MH: [
    "A","B","C","D","E","F","G","H","J","K","L","M","N","P","Q","R","S","T",
    "B Annex","C Annex","D Annex","E Annex","M Annex","N Annex"
  ],
  LH: ["A","B","C","D","E","F","G","H","J"],
};

const TAB_LIST = ["All","Pending","In Review","In Progress","Resolved","Rejected","Emergency"];
const STATUSES  = ["Submitted","Pending","In Review","In Progress","Resolved","Rejected"];
const PRIORITIES = ["Low","Medium","High","Emergency"];
const CATEGORIES = ["Safety","Maintenance","Food","Academics","Other"];

/* ---------------- Local log helpers ---------------- */
const LOG_KEY = "wcLogs"; // separate key to avoid clashing with Faculty
const readLogs = (id) => {
  try { const all = JSON.parse(localStorage.getItem(LOG_KEY) || "{}"); return all[id] || []; }
  catch { return []; }
};
const writeLogs = (id, next) => {
  try { const all = JSON.parse(localStorage.getItem(LOG_KEY) || "{}"); all[id] = next; localStorage.setItem(LOG_KEY, JSON.stringify(all)); }
  catch {}
};
const pushLog = (id, entry) => {
  const now = new Date();
  const payload = { ts: now.toISOString(), when: now.toLocaleString(), ...entry };
  const cur = readLogs(id);
  const next = [payload, ...cur];
  writeLogs(id, next);
  return next;
};

/* (Optional) If you used Faculty → Warden escalations via localStorage,
   you can also read from that inbox here. This board stays self-contained. */

export default function WardenComplaintBoard({ data = [] }) {
  const [items, setItems] = useState(data.length ? data : seed);

  // list header state
  const [active, setActive] = useState("All");
  const [sort, setSort] = useState("recent");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // modal & selection
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);

  // log drawer
  const [logOpen, setLogOpen] = useState(false);
  const [logs, setLogs] = useState([]);

  // escalate modal (same UX if wardens re-escalate onward)
  const [escalateOpen, setEscalateOpen] = useState(false);
  const [escForm, setEscForm] = useState({ hostelType: "", block: "" });

  // refs for focus management
  const logBtnRef = useRef(null);
  const logCloseBtnRef = useRef(null);

  // counts for tab badges
  const counts = useMemo(() => {
    const base = { All: items.length, Pending: 0, "In Review": 0, "In Progress": 0, Resolved: 0, Rejected: 0, Emergency: 0 };
    for (const it of items) {
      if (base[it.status] !== undefined) base[it.status] += 1;
      if (it.priority === "Emergency") base.Emergency += 1;
    }
    return base;
  }, [items]);

  // filter/sort/search
  const filtered = useMemo(() => {
    let list = [...items];
    if (active === "Emergency") list = list.filter((x) => x.priority === "Emergency");
    else if (active !== "All") list = list.filter((x) => x.status === active);

    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter(
        (x) =>
          x.id.toLowerCase().includes(t) ||
          x.title.toLowerCase().includes(t) ||
          (x.reporter || "").toLowerCase().includes(t) ||
          (x.regno || "").toLowerCase().includes(t)
      );
    }

    if (sort === "priority") {
      const rank = { Emergency: 3, High: 2, Medium: 1, Low: 0 };
      list.sort((a, b) => (rank[b.priority] ?? 0) - (rank[a.priority] ?? 0));
    } else if (sort === "category") list.sort((a, b) => a.cat.localeCompare(b.cat));
    return list;
  }, [items, active, sort, q]);

  // paging slice
  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const pageSafe = Math.min(page, totalPages);
  const start = (pageSafe - 1) * pageSize;
  const visible = filtered.slice(start, start + pageSize);

  // open/close helpers
  const openPanel = (it) => {
    setSelected({ ...it, adminNotes: it.adminNotes || "", tagInput: "" });
    setLogs(readLogs(it.id));
    setOpen(true);
    setLogOpen(false);
  };
  const mutate = (k, v) =>
    setSelected((s) => ({ ...s, [k]: typeof v === "function" ? v(s[k]) : v }));

  // record diffs on save (frontend-only log)
  const save = () => {
    if (!selected) return;
    const before = items.find((x) => x.id === selected.id) || {};
    const changes = [];
    [
      ["status", "Status"],
      ["priority", "Priority"],
      ["cat", "Category"],
      ["assignedTo", "Assigned To"],
    ].forEach(([key, label]) => {
      if (before[key] !== selected[key]) {
        changes.push(`${label}: “${before[key] ?? "—"}” → “${selected[key]}”`);
      }
    });

    if (changes.length) {
      const entry = {
        who: "Warden",
        action: "Edited case",
        note: changes.join("; "),
      };
      const next = pushLog(selected.id, entry);
      setLogs(next);
    }

    setItems((prev) =>
      prev.map((x) =>
        x.id === selected.id ? { ...selected, updated: "Just now" } : x
      )
    );
    setOpen(false);
  };

  const actionAndLog = (newStatus, actionLabel) => {
    if (!selected) return;
    mutate("status", newStatus);
    const next = pushLog(selected.id, {
      who: "Warden",
      action: actionLabel,
      note: `Status set to “${newStatus}”`,
    });
    setLogs(next);
  };

  // Escalate flow (optional reuse)
  const openEscalate = () => {
    if (!selected) return;
    const preType = selected.hostelType === "MH" || selected.hostelType === "LH" ? selected.hostelType : "";
    const preBlock = preType ? (selected.hostelBlock || "") : "";
    setEscForm({ hostelType: preType, block: preBlock });
    setEscalateOpen(true);
  };
  const confirmEscalate = () => {
    if (!selected) return;
    if (!escForm.hostelType || !escForm.block) {
      alert("Please select Hostel Type and Block to escalate.");
      return;
    }
    const assignTo = `Warden – ${escForm.hostelType} ${escForm.block}`;
    mutate("assignedTo", assignTo);
    mutate("status", "In Progress");

    const next = pushLog(selected.id, {
      who: "Warden",
      action: "Escalated",
      note: `Escalated to ${assignTo}`,
      meta: { hostelType: escForm.hostelType, block: escForm.block },
    });
    setLogs(next);

    setItems((prev) =>
      prev.map((x) =>
        x.id === selected.id
          ? { ...x, assignedTo: assignTo, status: "In Progress", updated: "Just now" }
          : x
      )
    );
    setEscalateOpen(false);
  };
  const cancelEscalate = () => setEscalateOpen(false);

  // Esc to close main modal
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  // Drawer: keep logs fresh when opened; ESC closes; focus management
  useEffect(() => {
    if (!selected) return;
    if (logOpen) {
      setLogs(readLogs(selected.id));
      const onKey = (e) => {
        if (e.key === "Escape") {
          setLogOpen(false);
          setTimeout(() => logBtnRef.current?.focus(), 0);
        }
      };
      window.addEventListener("keydown", onKey);
      return () => window.removeEventListener("keydown", onKey);
    }
  }, [logOpen, selected]);

  return (
    <WardenLayout>
      {/* ------- LIST PAGE ------- */}
      <div className="wardencomplaint-page">
        <header className="wardencomplaint-header">
          <div>
            <h1 className="wardencomplaint-title">Complaint Dashboard</h1>
            <p className="wardencomplaint-sub">Warden view – acknowledge, action, and resolve complaints.</p>
          </div>
          <div className="wardencomplaint-actions">
            <input
              className="wardencomplaint-search"
              value={q}
              onChange={(e) => { setQ(e.target.value); setPage(1); }}
              placeholder="Search by ID, title, or reg. no."
            />
            <select className="wardencomplaint-sort" value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="recent">Recent first</option>
              <option value="priority">By priority</option>
              <option value="category">By category</option>
            </select>
            <select
              className="wardencomplaint-sort"
              value={pageSize}
              onChange={(e) => { setPageSize(parseInt(e.target.value, 10)); setPage(1); }}
            >
              <option value={5}>5 / page</option>
              <option value={10}>10 / page</option>
              <option value={20}>20 / page</option>
              <option value={50}>50 / page</option>
              <option value={100}>100 / page</option>
            </select>
          </div>
        </header>

        <div className="wardencomplaint-tabs">
          {TAB_LIST.map((t) => (
            <button
              key={t}
              className={`wardencomplaint-tab ${active === t ? "active" : ""}`}
              onClick={() => { setActive(t); setPage(1); }}
              type="button"
            >
              <span>{t}</span>
              <span className="wardencomplaint-badge">{counts[t] ?? 0}</span>
              {active === t && <i className="wardencomplaint-underline" />}
            </button>
          ))}
        </div>

        <div className="wardencomplaint-list">
          {visible.map((c) => (
            <article
              key={c.id}
              className={`wardencomplaint-card ${String(c.priority || "").toLowerCase()} ${c.status === "Resolved" ? "is-ok" : ""}`}
              onClick={() => openPanel(c)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && openPanel(c)}
            >
              <div className="wardencomplaint-rail" />
              <div className="wardencomplaint-card-left">
                <h3 className="wardencomplaint-card-title">{c.title}</h3>
                <p className="wardencomplaint-id">{c.id}</p>
                <div className="wardencomplaint-meta">
                  <span>{c.reporter}</span>
                  <span>•</span>
                  <span>{c.regno}</span>
                  <span>•</span>
                  <span>{c.location}</span>
                </div>
              </div>
              <div className="wardencomplaint-card-right" onClick={(e) => e.stopPropagation()}>
                <span className="wardencomplaint-chip tone-cat">{c.cat}</span>
                <span className={`wardencomplaint-chip tone-${String(c.priority || "").toLowerCase()}`}>{c.priority}</span>
                <span className="wardencomplaint-chip tone-status">{c.status}</span>
                <span className="wardencomplaint-time">Updated: {c.updated}</span>
              </div>
            </article>
          ))}
          {!visible.length && (
            <div className="wardencomplaint-empty" style={{ marginTop: 12 }}>
              {total === 0 ? "No complaints found." : "No results on this page."}
            </div>
          )}
        </div>

        {Math.ceil(total / pageSize) > 1 && (
          <div className="wardencomplaint-pager">
            <button
              className="wardencomplaint-page-btn"
              disabled={pageSafe <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              type="button"
            >
              ← Prev
            </button>
            <div className="wardencomplaint-page-indicator">
              Page {pageSafe} / {Math.ceil(total / pageSize)}
            </div>
            <button
              className="wardencomplaint-page-btn"
              disabled={pageSafe >= Math.ceil(total / pageSize)}
              onClick={() => setPage((p) => p + 1)}
              type="button"
            >
              Next →
            </button>
          </div>
        )}
      </div>

      {/* ------- CASE PANEL ------- */}
      {open && selected && (
        <div className="wardencomplaint-modal show" onClick={() => setOpen(false)}>
          <div className="wardencomplaint-panel" onClick={(e) => e.stopPropagation()}>
            {/* Header */}
            <div className="wardencomplaint-panel-head" role="banner">
              <div className="wardencomplaint-titleblock">
                <h2 id="wc-panel-title">{selected.title}</h2>
                <p className="wardencomplaint-subid">{selected.id}</p>
              </div>
              <div className="wardencomplaint-head-actions">
                <button
                  ref={logBtnRef}
                  type="button"
                  className="wardencomplaint-btn ghost wardencomplaint-log-btn"
                  onClick={() => {
                    setLogs(readLogs(selected.id));
                    setLogOpen((v) => !v);
                    setTimeout(() => logCloseBtnRef.current?.focus(), 50);
                  }}
                  title="View case log"
                  aria-expanded={logOpen}
                  aria-controls="wc-log-drawer"
                >
                  View Log
                </button>
                <br />
                <button
                  className="wardencomplaint-close"
                  aria-label="Close"
                  onClick={() => setOpen(false)}
                  type="button"
                >
                  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                    <path
                      d="M6 6l12 12M18 6L6 18"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="wardencomplaint-panel-body">
              {/* Reporter */}
              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Reporter</h4>

                {selected.reporterType === "student" && (
                  <>
                    <div className="wardencomplaint-ro-grid">
                      <div>
                        <label>Name</label>
                        <div className="wardencomplaint-ro">{selected.reporter || "—"}</div>
                      </div>
                      <div>
                        <label>Reg / ID</label>
                        <div className="wardencomplaint-ro">{selected.regno || "—"}</div>
                      </div>
                      <div>
                        <label>Department</label>
                        <div className="wardencomplaint-ro">{selected.reporterDept || "—"}</div>
                      </div>
                      <div>
                        <label>Contact</label>
                        <div className="wardencomplaint-ro">{selected.reporterContact || "—"}</div>
                      </div>
                      <div>
                        <label>Submitted</label>
                        <div className="wardencomplaint-ro">{selected.submittedAt || "—"}</div>
                      </div>
                    </div>

                    <div className="wardencomplaint-ro-grid">
                      <div>
                        <label>Hostel Type</label>
                        <div className="wardencomplaint-ro">{selected.hostelType || "—"}</div>
                      </div>
                      <div>
                        <label>Block</label>
                        <div className="wardencomplaint-ro">{selected.hostelBlock || "—"}</div>
                      </div>
                      <div>
                        <label>Room</label>
                        <div className="wardencomplaint-ro">{selected.roomNumber || "—"}</div>
                      </div>
                    </div>
                  </>
                )}

                {selected.reporterType === "faculty" && (
                  <>
                    <div className="wardencomplaint-ro-grid">
                      <div>
                        <label>Faculty ID</label>
                        <div className="wardencomplaint-ro">{selected.facultyId || "—"}</div>
                      </div>
                      <div>
                        <label>Name</label>
                        <div className="wardencomplaint-ro">{selected.facultyName || "—"}</div>
                      </div>
                      <div>
                        <label>Department</label>
                        <div className="wardencomplaint-ro">{selected.facultyDept || "—"}</div>
                      </div>
                      <div>
                        <label>Designation</label>
                        <div className="wardencomplaint-ro">
                          {selected.facultyDesignation || "—"}
                        </div>
                      </div>
                      <div>
                        <label>Contact</label>
                        <div className="wardencomplaint-ro">{selected.facultyContact || "—"}</div>
                      </div>
                      <div>
                        <label>Submitted</label>
                        <div className="wardencomplaint-ro">{selected.submittedAt || "—"}</div>
                      </div>
                    </div>
                    {(selected.reporter || selected.regno) && (
                      <div className="wardencomplaint-note">
                        Filed about student: <b>{selected.reporter || "—"}</b>{" "}
                        ({selected.regno || "—"})
                      </div>
                    )}
                  </>
                )}
              </section>

              {/* Incident */}
              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Incident Details</h4>
                <div className="wardencomplaint-ro-grid">
                  <div>
                    <label>Category</label>
                    <div className="wardencomplaint-ro">{selected.cat || "—"}</div>
                  </div>
                  <div>
                    <label>Subcategory</label>
                    <div className="wardencomplaint-ro">{selected.subcategory || "—"}</div>
                  </div>
                  <div>
                    <label>Priority</label>
                    <div className="wardencomplaint-ro">{selected.priority || "—"}</div>
                  </div>
                  <div>
                    <label>Date & Time</label>
                    <div className="wardencomplaint-ro">{selected.incidentDateTime || "—"}</div>
                  </div>
                  <div className="wardencomplaint-span-2">
                    <label>Location / Place</label>
                    <div className="wardencomplaint-ro">{selected.location || "—"}</div>
                  </div>
                </div>
                <div className="wardencomplaint-ro-grid">
                  <div className="wardencomplaint-span-2">
                    <label>Title / Subject</label>
                    <div className="wardencomplaint-ro">
                      {selected.titleSubmitted || selected.title || "—"}
                    </div>
                  </div>
                </div>
                <label className="wc-lab">
                  Summary
                  <div className="wardencomplaint-roarea">{selected.summary || "—"}</div>
                </label>
                <label className="wc-lab">
                  Detailed Description
                  <div className="wardencomplaint-roarea">{selected.details || "—"}</div>
                </label>
              </section>

              {/* People */}
              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Victims</h4>
                {selected.victims?.length ? (
                  <ul className="wardencomplaint-people">
                    {selected.victims.map((v, i) => (
                      <li key={`v-${i}`} className="wardencomplaint-person">
                        <div className="wardencomplaint-person-line">
                          <b>{v.name || "—"}</b>
                          {v.reg ? <span className="wardencomplaint-tag">{v.reg}</span> : null}
                          {v.contact ? <span className="wardencomplaint-tag">{v.contact}</span> : null}
                        </div>
                        {v.description ? (
                          <div className="wardencomplaint-person-note">{v.description}</div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="wardencomplaint-muted">No victims recorded.</div>
                )}
              </section>

              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Accused (if identified)</h4>
                {selected.accused?.length ? (
                  <ul className="wardencomplaint-people">
                    {selected.accused.map((a, i) => (
                      <li key={`a-${i}`} className="wardencomplaint-person">
                        <div className="wardencomplaint-person-line">
                          <b>{a.name || "—"}</b>
                          {a.role ? (
                            <span className="wardencomplaint-tag">{String(a.role).toUpperCase()}</span>
                          ) : null}
                          {a.id ? <span className="wardencomplaint-tag">{a.id}</span> : null}
                          {a.contact ? <span className="wardencomplaint-tag">{a.contact}</span> : null}
                        </div>
                        {a.description ? (
                          <div className="wardencomplaint-person-note">{a.description}</div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="wardencomplaint-muted">No accused identified in report.</div>
                )}
              </section>

              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Witnesses</h4>
                {selected.witnesses?.length ? (
                  <ul className="wardencomplaint-people">
                    {selected.witnesses.map((w, i) => (
                      <li key={`w-${i}`} className="wardencomplaint-person">
                        <div className="wardencomplaint-person-line">
                          <b>{w.name || "—"}</b>
                          {(w.regNo || w.reg) ? (
                            <span className="wardencomplaint-tag">{w.regNo || w.reg}</span>
                          ) : null}
                          {w.contact ? <span className="wardencomplaint-tag">{w.contact}</span> : null}
                        </div>
                        {w.description ? (
                          <div className="wardencomplaint-person-note">{w.description}</div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="wardencomplaint-muted">No witnesses recorded.</div>
                )}
              </section>

              {/* Attachments */}
              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Attachments</h4>
                <div className="wardencomplaint-attachments">
                  {Array.isArray(selected.attachments) && selected.attachments.length ? (
                    <div className="wardencomplaint-files">
                      {selected.attachments.map((f, i) => (
                        <span key={i} className="wardencomplaint-file">
                          {typeof f === "string" ? f : f.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="wardencomplaint-chip tone-status">No attachments</span>
                  )}
                  <button className="wardencomplaint-btn ghost" type="button">View</button>
                  <button className="wardencomplaint-btn ghost" type="button">Add</button>
                </div>
              </section>

              {/* Case controls */}
              <section className="wardencomplaint-sec">
                <h4 className="wardencomplaint-sec-title">Case Controls</h4>
                <div className="wardencomplaint-edit">
                  <label>
                    Status
                    <select
                      value={selected.status}
                      onChange={(e) => mutate("status", e.target.value)}
                    >
                      {STATUSES.map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Priority
                    <select
                      value={selected.priority}
                      onChange={(e) => mutate("priority", e.target.value)}
                    >
                      {PRIORITIES.map((p) => (
                        <option key={p}>{p}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Category
                    <select
                      value={selected.cat}
                      onChange={(e) => mutate("cat", e.target.value)}
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Assigned To
                    <input
                      value={selected.assignedTo || ""}
                      onChange={(e) => mutate("assignedTo", e.target.value)}
                    />
                  </label>
                </div>
              </section>
            </div>

            {/* Sticky footer actions */}
            <div className="wardencomplaint-actionsbar">
              <textarea
                className="wardencomplaint-notes"
                rows={2}
                placeholder="Internal notes / decision log…"
                value={selected.adminNotes || ""}
                onChange={(e) => mutate("adminNotes", e.target.value)}
              />
              <div className="wardencomplaint-actionsrow">
                <button className="ok" onClick={save} type="button">Save</button>
                <button className="warn" onClick={openEscalate} type="button">Escalate</button>
                <button className="success" onClick={() => actionAndLog("Resolved", "Resolved")} type="button">Resolve</button>
                <button className="danger" onClick={() => actionAndLog("Rejected", "Rejected")} type="button">Reject</button>
              </div>
            </div>

            {/* --------- View Log Drawer ---------- */}
            <aside
              id="wc-log-drawer"
              className={`wardencomplaint-log-drawer ${logOpen ? "show" : ""}`}
              role="complementary"
              aria-label="Case Log"
              aria-hidden={!logOpen}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="wardencomplaint-log-head">
                <h4 style={{ margin: 0 }}>Case Log</h4>
                <span className="wardencomplaint-log-count">{logs.length} entries</span>
                <button
                  ref={logCloseBtnRef}
                  className="wardencomplaint-xbtn"
                  onClick={() => {
                    setLogOpen(false);
                    setTimeout(() => logBtnRef.current?.focus(), 0);
                  }}
                  type="button"
                  aria-label="Close log"
                  title="Close"
                >
                  ×
                </button>
              </div>

              <div className="wardencomplaint-log-body">
                {!logs.length ? (
                  <div className="wardencomplaint-log-empty">No activity yet.</div>
                ) : (
                  <ul className="wardencomplaint-timeline">
                    {logs.map((lg, i) => {
                      const type =
                        lg.action === "Resolved"
                          ? "Resolved"
                          : lg.action === "Rejected"
                          ? "Rejected"
                          : lg.action === "Escalated"
                          ? "Escalated"
                          : "Edited";
                      return (
                        <li key={i} className={`wardencomplaint-tl-item ${type}`}>
                          <span className="wardencomplaint-tl-dot" />
                          <div className="wardencomplaint-tl-card">
                            <div className="wardencomplaint-tl-top">
                              <span className="wardencomplaint-tl-action">{lg.action}</span>
                              <span className="wardencomplaint-tl-time">{lg.when}</span>
                            </div>
                            {lg.note && <div className="wardencomplaint-tl-note">{lg.note}</div>}
                            <div className="wardencomplaint-tl-meta">{lg.who ? `by ${lg.who}` : "—"}</div>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </aside>
            {/* --------- /View Log Drawer ---------- */}
          </div>
        </div>
      )}

      {/* ======= ESCALATE MODAL ======= */}
      {escalateOpen && (
        <div className="wardencomplaint-modal show" onClick={cancelEscalate}>
          <div
            className="wardencomplaint-panel wardencomplaint-escalate"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-label="Escalate Case"
          >
            <div className="wardencomplaint-panel-head">
              <div className="wardencomplaint-titleblock">
                <h2 style={{ marginBottom: 2 }}>Escalate</h2>
                <p className="wardencomplaint-subid">Select Hostel Type and Block</p>
              </div>
              <div className="wardencomplaint-head-actions">
                <button className="wardencomplaint-close" aria-label="Close" onClick={cancelEscalate} type="button">
                  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="wardencomplaint-panel-body">
              <section className="wardencomplaint-sec">
                <div className="wardencomplaint-edit">
                  <label>
                    Hostel Type
                    <select
                      value={escForm.hostelType}
                      onChange={(e) => setEscalateOpen((s) => (setEscForm(prev => ({ ...prev, hostelType: e.target.value, block: "" })), true))}
                    >
                      <option value="">— Select —</option>
                      <option value="MH">MH</option>
                      <option value="LH">LH</option>
                    </select>
                  </label>

                  <label>
                    Block
                    <select
                      value={escForm.block}
                      onChange={(e) => setEscForm((s) => ({ ...s, block: e.target.value }))}
                      disabled={!escForm.hostelType}
                    >
                      <option value="">{escForm.hostelType ? "— Select Block —" : "Choose hostel type first"}</option>
                      {(HOSTEL_OPTIONS[escForm.hostelType] || []).map((b) => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                    </select>
                  </label>
                </div>

                <div className="wardencomplaint-note" style={{ marginTop: 8 }}>
                  Wardens of the selected block will be notified.
                </div>
              </section>
            </div>

            <div className="wardencomplaint-actionsbar">
              <textarea
                className="wardencomplaint-notes"
                rows={2}
                placeholder="Optional message (stored in log only)…"
                value={selected?.adminNotes || ""}
                onChange={(e) => mutate("adminNotes", e.target.value)}
              />
              <div className="wardencomplaint-actionsrow">
                <button className="ok" type="button" onClick={confirmEscalate}>Confirm</button>
                <button className="danger" type="button" onClick={cancelEscalate}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </WardenLayout>
  );
}
